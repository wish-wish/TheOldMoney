/******************************************************************************** 
 * create:cclin
 * date:2014-11-5
 * ver:
 * latest update:
 * function:
 * update log:
 * <author>  <time>           <version >   <desc>
 *********************************************************************************/
#include "UIEffectManager.h"
//#include "gamelogic/BattleCommon.h"
//#include "ClientCommon.h"

#define floatcompareval 0.00001
#define UI_EFFECT_ANIMATION_FILENAME	 "effect/ui_effect.ExportJson"
#define UI_EFFECT_ARMATURE_NAME	 "ui_effect"

UIEffectManager::UIEffectManager()
{	
	//ArmatureDataManager::getInstance()->addArmatureFileInfo(EFFECT_JSON_FOLDER("ui_effect"));
	//ArmatureDataManager::getInstance()->addArmatureFileInfo(EFFECT_JSON_FOLDER("recruit"));
	//ArmatureDataManager::getInstance()->addArmatureFileInfo(EFFECT_JSON_FOLDER("ui_chuangjian_effect"));	
	this->retain();
}

UIEffectManager::~UIEffectManager()
{
	stopAllEffects();
	this->release();
}

Armature* UIEffectManager::moveEffect(Node* parent,const EFFECT_FUNC func ,const char* animName ,const NODE_FUNC nodefunc,const Vec2& destpos,float duration/*=2.0f*/, const Vec2& offset/*=Vec2::ZERO*/,int newtag/*=0*/)
{
	Armature* arm= this->playEffect(parent,func,animName);
	parent->setUserData(arm);
	MoveTo* move=MoveTo::create(duration,destpos);
	CallFuncN* endfunc=CallFuncN::create(this,callfuncN_selector(UIEffectManager::onMoveEnd));
	Sequence* seq=Sequence::create(move,endfunc,NULL);
	parent->runAction(seq);
	if(nodefunc!=nullptr){
		m_effectNode.insert(make_pair(arm, nodefunc));
	}
	return arm;
}

Armature* UIEffectManager::playEffect(Node* parent,const EFFECT_FUNC func ,const char* animName ,const Vec2& offset,int noloop,int newtag)
{
	return this->playEffect(parent,UI_EFFECT_ANIMATION_FILENAME,UI_EFFECT_ARMATURE_NAME,func,animName,offset,noloop,newtag);
}

Armature* UIEffectManager::playEffect(Node* parent,const char* effectJson,const char* armatureAniName, const EFFECT_FUNC func ,const char* animName ,const Vec2& offset,int noloop,int newtag,float duration)
{	
	//CCLOG("UIEffectManager::playEffect=%s anim=%s tick=%lld start",effectJson,animName,time(0));
	Node* root = parent;		
	ArmatureDataManager::getInstance()->addArmatureFileInfo(effectJson);
	Armature* armature = Armature::create(armatureAniName);
    if(armature!=NULL&& armature->getAnimation()!=NULL){  //fix crash bug
        armature->getAnimation()->setMovementEventCallFunc(EFFECT_CALLBACK_3(UIEffectManager::animCallback,this));
    }			
	m_effectPlay[armature]=func;
	int loop=-1;
	if(noloop==0)
	{
		loop=1;
	}else if(noloop==-1)
	{
		loop=-1;
	}else if(noloop==1)
	{
		loop=0;
	}
	m_effectLoop[armature]=loop;
	Vec2 p=offset+parent->getContentSize()/2;
	armature->setPosition(p);
	if(newtag == 0){
		root->addChild(armature,104);
	}else{
		if(root->getChildByTag(newtag)==NULL){
			root->addChild(armature);
			armature->setTag(newtag);
		}else{
			CCLOG("Already add the effect");
		}
	}
    if(armature!=NULL && armature->getAnimation()!=NULL){  
		if(fabs(duration-0)>floatcompareval)
		{
			armature->getAnimation()->play(animName,-1, 1);
		}else
		{
			armature->getAnimation()->play(animName,-1, loop);						
		}		
    }
	m_effectduration[armature]=duration;
	if(fabs(duration-0)>floatcompareval)
	{
		Sequence* seq=Sequence::create(DelayTime::create(duration),CallFuncN::create(this,callfuncN_selector(UIEffectManager::onDurationEnd)));		
		armature->runAction(seq);
	}
	//CCLOG("UIEffectManager::playEffect=%s anim=%s tick=%lld end",effectJson,animName,time(0));
	return armature;
}

void UIEffectManager::stopAllEffects()
{
	if(!m_effectPlay.empty()&&m_effectPlay.size()>0){		
		for(EffectMapPlay::iterator pos = m_effectPlay.begin(); pos!= m_effectPlay.end(); ++pos){
			Armature* armature =dynamic_cast<Armature*>(pos->first);						
			this->erasePlayCallBack(armature);
			if(armature){
				armature->stopAllActions();
				if(armature->getAnimation()!=NULL){  //fix crash bug
					armature->getAnimation()->stop();
				}
				armature->removeFromParentAndCleanup(true);
			}
		}
		m_effectPlay.clear();
		m_effectNode.clear();
		m_effectLoop.clear();
		m_effectduration.clear();
	}
}


void UIEffectManager::animCallback(Armature* armature,MovementEventType movementType,const string& movementID)
{
	EffectMapPlay::iterator pos = m_effectPlay.find(armature);
	EffectMapLoop::iterator lpos = m_effectLoop.find(armature);
	if(pos != m_effectPlay.end()){
		if(pos->second!=nullptr){
			if(movementType==COMPLETE||movementType==LOOP_COMPLETE)
			{
				if(lpos!=m_effectLoop.end()&&lpos->second)
				{
					pos->second(armature,LOOP_COMPLETE,movementID);
				}
				else
				{
					pos->second(armature,COMPLETE,movementID);
				}
			}			
		}		
	}
	if(movementType==COMPLETE||movementType==LOOP_COMPLETE)
	{              
		string moveid=armature->getAnimation()->getCurrentMovementID();
		MovementData* data=armature->getAnimation()->getAnimationData()->getMovement(moveid);
		bool loop=false;
		if(data!=NULL&&lpos!=m_effectLoop.end())
		{
			if(lpos->second<0)
				loop=data->loop;
			else if(lpos->second>0)
				loop=true;
			else
				loop=false;			
		}		
		if((!loop)&&(fabs(m_effectduration[armature]-0)<floatcompareval))
		{
			this->erasePlayCallBack(armature);
			armature->stopAllActions();
            if(armature->getAnimation()!=NULL){  //fix crash bug
                armature->getAnimation()->stop();
            }
			armature->removeFromParentAndCleanup(true);						
		}		
	}
}

void UIEffectManager::erasePlayCallBack(Armature* armature)
{
	EffectMapPlay::iterator pos = m_effectPlay.find(armature);
	if(pos!=m_effectPlay.end())
	{
		pos->second = nullptr;
		m_effectPlay.erase(pos);
	}
	EffectMapLoop::iterator lpos=m_effectLoop.find(armature);
	if(lpos!=m_effectLoop.end())
	{
		m_effectLoop.erase(lpos);
	}
	EffectDuration::iterator edpos=m_effectduration.find(armature);
	if(edpos!=m_effectduration.end())
	{
		m_effectduration.erase(edpos);
	}
	EffectMapNode::iterator npos=m_effectNode.find(armature);
	if(npos!=m_effectNode.end())
	{
		m_effectNode.erase(npos);
	}
}

void UIEffectManager::onMoveEnd(Node* n)
{
	Armature* arm=(Armature*)n->getUserData();
	EffectMapNode::iterator pos = m_effectNode.find(arm);
	if(pos!=m_effectNode.end())
	{		
		pos->second(n);		
		pos->second=nullptr;
	}
	this->erasePlayCallBack(arm);
	if(NULL!=arm)
	{
		arm->stopAllActions();
        if(arm->getAnimation()!=NULL){  //fix crash bug
            arm->getAnimation()->stop();
        }
		arm->removeFromParentAndCleanup(true);
	}
}

bool UIEffectManager::isEffectPlay(Node* n,int tag)
{
	Armature* efn=(Armature*)n->getChildByTag(tag);
	if(efn==NULL)
		return false;
	if(efn->getAnimation()==NULL)
		return false;
	return efn->getAnimation()->isPlaying();
}

void UIEffectManager::onDurationEnd(Node* n)
{
	Armature* arm=(Armature*)n;
	EffectMapPlay::iterator pos = m_effectPlay.find(arm);
	if(pos->second!=nullptr&&arm!=nullptr&&arm->getAnimation()!=nullptr)
	{
		pos->second(arm,COMPLETE,arm->getAnimation()->getCurrentMovementID());
		pos->second=nullptr;
	}	
	this->erasePlayCallBack(arm);
	if(NULL!=arm)
	{
		arm->stopAllActions();
		if(arm->getAnimation()!=NULL){  //fix crash bug
			arm->getAnimation()->stop();
		}
		arm->removeFromParentAndCleanup(true);
	}	
}

bool UIEffectManager::stopEffect(Node* n,int tag)
{
	Armature* armature =(Armature*)n->getChildByTag(tag);
	if(armature!=NULL){		
		this->erasePlayCallBack(armature);
		armature->stopAllActions();
		if(armature->getAnimation()!=NULL){  //fix crash bug
			armature->getAnimation()->stop();
		}
		armature->removeFromParentAndCleanup(true);
		return true;
	}
	return false;
}

bool UIEffectManager::removeEffect(Armature* effect)
{
	EffectMapPlay::iterator pos=m_effectPlay.find(effect);
	if(effect!=NULL&&pos!=m_effectPlay.end()){		
		this->erasePlayCallBack(effect);
		effect->stopAllActions();
		if(effect->getAnimation()!=NULL){  //fix crash bug
			effect->getAnimation()->stop();
		}
		effect->removeFromParentAndCleanup(true);
		return true;
	}
	return false;
}


