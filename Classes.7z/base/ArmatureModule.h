/******************************************************************************** 
 * create:cclin
 * date:2015-02-25
 * ver:
 * latest update:
 * function:������
 * update log:
 * <author>  <time>           <version >   <desc>
 *********************************************************************************/
#pragma once

#include "cocos2d.h"
#include "base/Singleton.h"
//#include "base/ClientCommon.h"
#include "CocosGUI.h"
#include "ActionModule.h"
#include "cocostudio/CocoStudio.h"


USING_NS_CC;
using namespace std;
using namespace ui;
using namespace cocostudio;

class ArmatureModule:public Singleton<ArmatureModule>,public Node
{
public:
	ArmatureModule();
	~ArmatureModule();
public:
    
    void AddArmatureDataFile(string file);
    
    Armature* PlayAround(string arm_name,string anim,Rect rect,CallFuncN* onedone=nullptr,float livets=0,AroundType rt=rtClockWise);
    Armature* PlayAroundDouble(string arm_name,string anim,Rect rect,CallFuncN* onedone=nullptr,float livets=0,AroundType rt=rtClockWise);
    Armature* PlayMove(string arm_name,string anim,Vec2 DestPos,Vec2 SrcPos=Vec2::ZERO,CallFuncN* onedone=nullptr,float livets=0);
    Armature* PlaySize(string arm_name,string anim,Rect rect);
private:
    
};