/******************************************************************************** 
 * create:cclin
 * date:2014-11-5
 * ver:
 * latest update:
 * function: armatuer play, change from effectmanage
 * update log:
 * <author>  <time>           <version >   <desc>
 *********************************************************************************/
#ifndef __EFFECT_MANAGER_EXT_H__
#define __EFFECT_MANAGER_EXT_H__

#include "cocos2d.h"
#include "ui/CocosGUI.h"
#include "Singleton.h"
#include "cocostudio/CocoStudio.h"

using namespace cocos2d::ui;
using namespace cocos2d;
using namespace cocostudio;
using namespace std;

typedef function<void(Armature* armature,MovementEventType movementType,const std::string& movementID)> EFFECT_FUNC;
#define EFFECT_CALLBACK_3(func, _Object) bind(&func,_Object, placeholders::_1,placeholders::_2,placeholders::_3)
typedef function<void(Node*)> NODE_FUNC;
#define NODE_CALLBACK_1(func,_Object) bind(&func,_Object,placeholders::_1)

class UIEffectManager : public Singleton<UIEffectManager>,public Node
{
public:

	UIEffectManager();
	~UIEffectManager();

public:		
	Armature* moveEffect(Node* parent,const EFFECT_FUNC func ,const char* animName ,const NODE_FUNC nodefunc, const Vec2& destpos,float duration=2.0f,const Vec2& offset=Vec2::ZERO,int newtag=0);

	Armature* playEffect(Node* parent,const EFFECT_FUNC func ,const char* animName ,const Vec2& offset=Vec2::ZERO,int noloop = 0,int newtag = 0);
	Armature* playEffect(Node* parent,const char* effectJson,const char* armatureAniName, const EFFECT_FUNC func ,const char* animName ,const Vec2& offset=Vec2::ZERO,int noloop = 0,int newtag = 0,float duration=0.0f);
	
	void erasePlayCallBack(Armature* armature);		 

	bool isEffectPlay(Node* parent,int tag);
	bool stopEffect(Node* parent,int tag);

	bool removeEffect(Armature* effect);//must use UIEffectManager play suits
private:	
	void animCallback(Armature* armature,MovementEventType movementType,const string& movementID);
	void onMoveEnd(Node* n);
	void onDurationEnd(Node* n);
    typedef     map<Armature* ,EFFECT_FUNC> EffectMapPlay;
	typedef		map<Armature* ,NODE_FUNC> EffectMapNode;
	typedef     map<Armature* ,int>  EffectMapLoop;
	typedef     map<Armature* ,float> EffectDuration; 
	typedef     vector<Sequence*> DurationAction;

    EffectMapPlay  m_effectPlay;
	EffectMapNode  m_effectNode;
	EffectMapLoop  m_effectLoop;		
	EffectDuration m_effectduration;
	DurationAction m_DurationAction;

	void stopAllEffects();
};

#endif // __EFFECT_MANAGER_H__
