/******************************************************************************** 
 * create:cclin
 * date:2015-02-25
 * ver:
 * latest update:
 * function:
 * update log:
 * <author>  <time>           <version >   <desc>
 *********************************************************************************/
#include "ArmatureModule.h"

ArmatureModule::ArmatureModule()
{
	this->retain();
}

ArmatureModule::~ArmatureModule()
{
	this->release();
}

void ArmatureModule::AddArmatureDataFile(string file)
{
    ArmatureDataManager::getInstance()->addArmatureFileInfo(file);
}

Armature* ArmatureModule::PlayAround(string arm_name,string anim,Rect rect,CallFuncN* onedone,float livets,AroundType rt)
{
    Armature* armature = Armature::create(arm_name);
    
    //Director::getInstance()->getRunningScene()->addChild(armature,Armature_ZOrder);
    float x=rect.getMinX();
    float y=rect.getMinY();
    armature->setPosition(Vec2(x,y));
    Sequence* seq=ActionModule::getInstance()->NewAroundAction(rect,Vec2(x,y),onedone,livets,rt);
    RepeatForever* rep=RepeatForever::create(seq);
    armature->runAction(rep);
    
    armature->getAnimation()->play(anim);
    return armature;
}

Armature* ArmatureModule::PlayAroundDouble(string arm_name,string anim,Rect rect,CallFuncN* onedone,float livets,AroundType rt)
{
    Armature* armature = Armature::create(arm_name);
    //Director::getInstance()->getRunningScene()->addChild(armature,Armature_ZOrder);
    float x=rect.getMinX();
    float y=rect.getMinX();
    armature->setPosition(Vec2(x,y));
    Sequence* seq=ActionModule::getInstance()->NewAroundAction(rect,Vec2(x,y),onedone,livets,rt);
    RepeatForever* rep=RepeatForever::create(seq);
    armature->runAction(rep);
    
    armature->getAnimation()->play(anim);
    
    Armature* armature2 = Armature::create(arm_name);
    //Director::getInstance()->getRunningScene()->addChild(armature2,Armature_ZOrder);
    armature2->setPosition(Vec2(rect.getMaxX(),rect.getMaxY()));
    seq=ActionModule::getInstance()->NewAroundAction(rect,Vec2(rect.getMaxX(),rect.getMaxY()),onedone,livets,rt);
    rep=RepeatForever::create(seq);
    armature2->runAction(rep);
    
    armature2->getAnimation()->play(anim);
    armature->setUserData((void*)armature2);
    return armature;
}

Armature* ArmatureModule::PlayMove(string arm_name,string anim,Vec2 DestPos,Vec2 SrcPos,CallFuncN* onedone,float livets)
{
    Armature* armature = Armature::create(arm_name);
    //Director::getInstance()->getRunningScene()->addChild(armature,Armature_ZOrder);
    armature->setPosition(SrcPos);
    float playtts=livets;
    if (playtts<0.0001) {
        playtts=1.0;
    }
    Sequence* seq=Sequence::create(CCMoveTo::create(playtts, DestPos),onedone, NULL);
    armature->runAction(seq);
    armature->getAnimation()->play(anim);
    return armature;
}

Armature* ArmatureModule::PlaySize(string arm_name,string anim,Rect rect)
{
    Armature* armature = Armature::create(arm_name);
    //Director::getInstance()->getRunningScene()->addChild(armature,Armature_ZOrder);
    armature->setPosition(rect.origin);
    //armature->setContentSize(rect.size);
    float scalex=rect.size.width/armature->getBoundingBox().size.width;
    float scaley=rect.size.height/armature->getBoundingBox().size.height;
    armature->setScaleX(scalex);
    armature->setScaleY(scaley);
    armature->getAnimation()->play(anim);
    armature->setAnchorPoint(Vec2(0,0));
    return armature;
}



