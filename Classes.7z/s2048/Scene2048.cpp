
#include "Scene2048.h"

USING_NS_CC;

Scene* Scene_2048::createScene()
{
	auto scene = Scene::create();
	auto layer = Scene_2048::create();
	scene->addChild(layer);
	return scene;
}

bool Scene_2048::init()
{
	if ( !Scene::init() )
	{
		return false;
	}
    
    FileUtils::getInstance()->addSearchPath("r2048",true);
	Size visibleSize = Director::getInstance()->getVisibleSize();
	Point origin = Director::getInstance()->getVisibleOrigin();

	//add touch listener
	auto touchListener = EventListenerTouchOneByOne::create();
	touchListener->onTouchBegan = CC_CALLBACK_2(Scene_2048::onTouchBegan, this);
	touchListener->onTouchEnded = CC_CALLBACK_2(Scene_2048::onTouchEnded, this);
	_eventDispatcher->addEventListenerWithSceneGraphPriority(touchListener, this);

	//add background
	auto layerColorBG = LayerColor::create(Color4B(180, 170, 160, 255));
	this->addChild(layerColorBG);
	
	//create score

	score = 0;
	cardNumberTTF = Label::create("", "Consolas", 70);
	cardNumberTTF->setPosition(Vec2(visibleSize.width/2, visibleSize.height - 50));
	addChild(cardNumberTTF);
    
    maxNumber = Label::create("", "Consolas", 70);
    maxNumber->setPosition(Vec2(visibleSize.width/2, visibleSize.height - 120));
    addChild(maxNumber);
    
    m_RCount = CardDispManager::getInstance()->GetDefRows();
    
	//创建4X4卡片
	createCardSprite(visibleSize,Vec2::ZERO);
    
	//初始时生成两个2
	createCardNumber();
	createCardNumber();
    
    Button* btnPrior=Button::create();
    btnPrior->setPosition(Vec2(visibleSize.width-200, m_RCount*m_CardSize + 80));
    btnPrior->setTitleText("Prior");
    btnPrior->setTitleFontSize(30);
    btnPrior->addTouchEventListener(CC_CALLBACK_2(Scene_2048::onPrior, this));
    addChild(btnPrior);
    
    Button* btnNext=Button::create();
    btnNext->setPosition(Vec2(visibleSize.width-100, m_RCount*m_CardSize + 80));
    btnNext->setTitleText("Next");
    btnNext->setTitleFontSize(30);
    btnNext->addTouchEventListener(CC_CALLBACK_2(Scene_2048::onNext, this));
    addChild(btnNext);
    
	return true;
}

void Scene_2048::onNext(Ref* ref,Widget::TouchEventType type)
{
    if(type==Widget::TouchEventType::ENDED)
    {
        CardDispData* data=m_DispData->getNextData();
        if (data!=nullptr) {
            m_DispData=data;
            this->showCardsNumber(data);
        }
    }
}

void Scene_2048::onPrior(Ref* ref,Widget::TouchEventType type)
{
    if(type==Widget::TouchEventType::ENDED)
    {
        CardDispData* data=m_DispData->getPriorData();
        if (data!=nullptr) {
            m_DispData=data;
            this->showCardsNumber(data);
        }
    }
}

void Scene_2048::showCardsNumber(CardDispData* data)
{
    if (data==nullptr) {
        return;
    }
    NumberList* list=data->getNumberList();
    for (int i=0; i<list->size(); i++) {
        int x=i/m_RCount;
        int y=i%m_RCount;
        cardArr[x][y]->setNumber((*list)[i]);
        cardArr[x][y]->swapBuffer();
    };
}

void Scene_2048::saveStepData(CardDispData* data)
{
    for (int i=0; i<m_RCount; i++) {
        for (int j=0; j<m_RCount; j++) {
            data->setData(i, j, cardArr[i][j]->getNumber());
        }
    }
}

void Scene_2048::writeHistoryData()
{
    CardDispManager::getInstance()->writeDataList();
}

void Scene_2048::destoryCardSprite()
{
    for (int i = 0; i < m_RCount; i++)
    {
        for (int j = 0; j < m_RCount; j++)
        {
            if (cardArr[i][j]!=NULL) {
                cardArr[i][j]->removeFromParentAndCleanup(true);
                cardArr[i][j]=NULL;
            }
        }
    }
}

//create card with screen size
void Scene_2048::createCardSprite(Size size,Vec2 offset)
{
    int maxwidth=size.width<size.height?size.width:size.height;
	int cardSize = (maxwidth-GridBrder*2) / m_RCount;
    m_CardSize = cardSize;
    
	//绘制出nXn的单元格
    CCLOG("createCardSprite %d * %d",m_RCount,m_RCount);
	for (int i = 0; i < m_RCount; i++)
	{
		for (int j = 0; j < m_RCount; j++)
		{
			//need screen pixels match
			CardSprite *card = CardSprite::createCardSprite(0, cardSize, cardSize, cardSize*i+GridBrder+offset.x, cardSize*j+GridBrder+offset.y);
            card->setGridPos(i, j);
			cardArr[i][j] = card;
			addChild(card);
		}
	}
}

void Scene_2048::changeRowCount(int count)
{
    this->destoryCardSprite();
    m_RCount = count;
    
    CardDispManager::getInstance()->SetDefRows(m_RCount);
    
    Size visibleSize = Director::getInstance()->getVisibleSize();
    this->createCardSprite(visibleSize,Vec2::ZERO);
}

bool Scene_2048::onTouchBegan(Touch* touch, Event* event)
{
	Vec2 beginTouch = touch->getLocation();  //获取OpenGL坐标，以左下角为原点
	beginX = beginTouch.x;
	beginY = beginTouch.y;

	return true;
}

void Scene_2048::onTouchEnded(Touch* touch, Event* event)
{
	Vec2 endTouch = touch->getLocation();  //获取OpenGL坐标，以左下角为原点
	//计算手指在X，Y移动的距离
	//CCLOG("x=%f y=%f",endTouch.x,endTouch.y);
	endX = beginX - endTouch.x;
	endY = beginY - endTouch.y;
    
    if (!m_isAnimating) {
        this->logic2048();
    }
}

void Scene_2048::logic2048()
{
    this->doBackNumbers();
    bool isMove=false;
    if (abs(endX) > abs(endY))
    {
        //如果X轴移动的距离大于Y轴，则是左右移动
        if (endX + 5 > 0)
        {
            if (doLeft())
            {
                getSrcLeft();
                isMove=true;
            }
        }
        else
        {
            if (doRight())
            {
                getSrcRight();
                isMove=true;
            }
        }
    }
    else
    {
        if (endY + 5 > 0)
        {
            if (doDown())
            {
                getSrcDown();
                isMove=true;
            }
        }
        else
        {
            if (doUp())
            {
                getSrcUp();
                isMove=true;
            }
        }
    }
    doCheck();
    doAnimations();
    if (isMove) {
        createCardNumber();
    }
}

void Scene_2048::clearUseds()
{
    for (int y = 0; y < m_RCount; y++)
    {
        for (int x = 0; x < m_RCount; x++)
        {
            cardArr[x][y]->m_SrcUsed = false;
            cardArr[x][y]->m_DstUsed = false;
            cardArr[x][y]->m_SrcPos.clear();
        }
    }
}

void Scene_2048::doBackNumbers()
{
    for (int y = 0; y < m_RCount; y++)
    {
        for (int x = 0; x < m_RCount; x++)
        {
            cardArr[x][y]->setOldNumber(cardArr[x][y]->getNumber());
            cardArr[x][y]->m_SrcUsed = false;
            cardArr[x][y]->m_DstUsed = false;
        }
    }
}

void Scene_2048::doAnimations()
{
    m_isDirty = false;
    m_isAnimating = false;
    for (int y = 0; y < m_RCount; y++)
    {
        for (int x = 0; x < m_RCount; x++)
        {
            for (int j=0;j<cardArr[x][y]->m_SrcPos.size();j++) {
                m_isDirty = true;
                m_isAnimating = true;
                int srcx=cardArr[x][y]->m_SrcPos[j].x;
                int srcy=cardArr[x][y]->m_SrcPos[j].y;
                if(srcx==x&&srcy==y)
                {
                    cardArr[x][y]->m_DstPos=Vec2(x,y);
                    int oldnum=cardArr[x][y]->getOldNumber();
                    
                    cardArr[x][y]->setDispNumber(oldnum);
                    Color3B color=CardSprite::GetBackColor(cardArr[x][y]->getNumber());
                    TintTo* tint=TintTo::create(AniTime, color.r, color.g, color.b);
                    cardArr[x][y]->runAction(Sequence::create(DelayTime::create(AniTime),
                                                              CallFunc::create(CC_CALLBACK_0(Scene_2048::swapCard,this,cardArr[x][y])),NULL));
                    cardArr[x][y]->getBackground()->runAction(tint);
                    //CCLOG("delayshow old=%d new=%d x=%d y=%d",oldnum,cardArr[x][y]->getNumber(),x,y);
                }
                else
                {
                    cardArr[srcx][srcy]->setDispNumber(0);
                    
                    CardSprite *card = CardSprite::createCardSprite(cardArr[srcx][srcy]->getOldNumber(), m_CardSize, m_CardSize, m_CardSize*srcx+GridBrder, m_CardSize*srcy+GridBrder);
                    card->swapBuffer();
                    addChild(card,100);
                    
                    card->m_DstPos=Vec2(x, y);
                    
                    Color3B color=CardSprite::GetBackColor(cardArr[x][y]->getNumber());
                    TintTo* tint=TintTo::create(AniTime, color.r, color.g, color.b);
                    MoveTo* move=MoveTo::create(AniTime, cardArr[x][y]->GetCardPostion());
                    card->runAction(Sequence::create(move,
                                                     CallFunc::create(CC_CALLBACK_0(Scene_2048::removeCard,this,card)),NULL)
                                     );
                    card->getBackground()->runAction(tint);
                    //CCLOG("move old=%d new=%d x=%d y=%d dstx=%d y=%d",cardArr[x][y]->getOldNumber(),cardArr[x][y]->getNumber(),srcx,srcy,x,y);
                }
            }
        }
    }
}


void Scene_2048::removeCard(CardSprite* b)
{
    this->swapCard(b);
    b->removeFromParentAndCleanup(true);
}

void Scene_2048::swapCard(CardSprite* b)
{
    int x=b->m_DstPos.x;
    int y=b->m_DstPos.y;
    cardArr[x][y]->swapBuffer();
    if (m_isDirty) {
        m_isDirty = false;
        setScore(score);
    }
    if (m_isMove) {
        m_isMove=false;
        createCardNumber();
    }
    m_isAnimating = false;
}

void Scene_2048::doDisplayNumbers()
{
    for (int y = 0; y < m_RCount; y++)
    {
        for (int x = 0; x < m_RCount; x++)
        {
            cardArr[x][y]->swapBuffer();
        }
    }
}

void Scene_2048::getSrcLeft()
{
    this->clearUseds();
    for (int y = 0; y < m_RCount; y++)
    {
        for (int x = 0; x < m_RCount; x++)
        {
            if(cardArr[x][y]->getNumber()==0) continue;
            
            if(cardArr[x][y]->getOldNumber()==cardArr[x][y]->getNumber()&&!cardArr[x][y]->m_SrcUsed)
            {
                cardArr[x][y]->m_SrcUsed = true;
                cardArr[x][y]->m_DstUsed = true;
                continue;
            }
            
            for (int j=x; j<m_RCount-2; j++) {//three
                if(cardArr[j][y]->getOldNumber()>0&&!cardArr[j][y]->m_SrcUsed)
                {
                    int jj=-1;
                    int jjj=-1;
                    for (int k=j+1; k<m_RCount; k++) {
                        if(cardArr[k][y]->getOldNumber()>0&&!cardArr[k][y]->m_SrcUsed)
                        {
                            jj=k;
                            for (int m=k+1; m<m_RCount; m++) {
                                if(cardArr[m][y]->getOldNumber()>0&&!cardArr[m][y]->m_SrcUsed)
                                {
                                    jjj=m;
                                    break;
                                }
                            }
                            break;
                        }
                    }
                    if (jj==-1||jjj==-1) {
                        break;
                    }
                    if(cardArr[x][y]->getNumber()==cardArr[j][y]->getOldNumber()+cardArr[jj][y]->getOldNumber()+cardArr[jjj][y]->getOldNumber()&&!cardArr[x][y]->m_DstUsed)
                    {
                        
                        cardArr[j][y]->m_SrcUsed=true;
                        cardArr[jj][y]->m_SrcUsed=true;
                        cardArr[jjj][y]->m_SrcUsed=true;
                        cardArr[x][y]->addSrcPos(j,y);
                        cardArr[x][y]->addSrcPos(jj,y);
                        cardArr[x][y]->addSrcPos(jjj,y);
                        cardArr[x][y]->m_DstUsed = true;
                        
                    }
                }
            }
            
            for (int j=x; j<m_RCount-1; j++) {//two
                if(cardArr[j][y]->getOldNumber()>0&&!cardArr[j][y]->m_SrcUsed)
                {
                    int jj=-1;
                    for (int k=j+1; k<m_RCount; k++) {
                        if(cardArr[k][y]->getOldNumber()>0&&!cardArr[k][y]->m_SrcUsed)
                        {
                            jj=k;
                            break;
                        }
                    }
                    if (jj==-1) {
                        break;
                    }
                    if(cardArr[x][y]->getNumber()==cardArr[j][y]->getOldNumber()+cardArr[jj][y]->getOldNumber()&&!cardArr[x][y]->m_DstUsed)
                    {
                        cardArr[j][y]->m_SrcUsed=true;
                        cardArr[jj][y]->m_SrcUsed=true;
                        cardArr[x][y]->addSrcPos(j,y);
                        cardArr[x][y]->addSrcPos(jj,y);
                        cardArr[x][y]->m_DstUsed = true;
                        
                    }
                }
            }
            
            //one
            int i=-1;
            for (int j=x; j<m_RCount; j++) {
                if (cardArr[j][y]->getOldNumber()>0&&!cardArr[j][y]->m_SrcUsed) {
                    i=j;
                    break;
                }
            }
            
            if(i>=0&&!cardArr[x][y]->m_DstUsed)
            {
                cardArr[i][y]->m_SrcUsed = true;
                cardArr[x][y]->addSrcPos(i,y);
                cardArr[x][y]->m_DstUsed = true;
            }
            
        }
    }
}

void Scene_2048::getSrcRight()
{
    this->clearUseds();
    for (int y = 0; y < m_RCount; y++)
    {
        for (int x = m_RCount-1; x >= 0; x--)
        {
            if(cardArr[x][y]->getNumber()==0) continue;
            
            if(cardArr[x][y]->getOldNumber()==cardArr[x][y]->getNumber()&&!cardArr[x][y]->m_SrcUsed)
            {
                cardArr[x][y]->m_SrcUsed = true;
                cardArr[x][y]->m_DstUsed = true;
                continue;
            }
            
            
            for (int j=x; j>1; j--) {//three
                if(cardArr[j][y]->getOldNumber()>0&&!cardArr[j][y]->m_SrcUsed)
                {
                    int jj=-1;
                    int jjj=-1;
                    for (int k=j-1; k>0; k--) {
                        if(cardArr[k][y]->getOldNumber()>0&&!cardArr[k][y]->m_SrcUsed)
                        {
                            jj=k;
                            for (int m=k-1; m>=0; m--) {
                                if(cardArr[m][y]->getOldNumber()>0&&!cardArr[m][y]->m_SrcUsed)
                                {
                                    jjj=m;
                                    break;
                                }
                            }
                            break;
                        }
                    }
                    if (jj==-1||jjj==-1) {
                        break;
                    }
                    if(cardArr[x][y]->getNumber()==cardArr[j][y]->getOldNumber()+cardArr[jj][y]->getOldNumber()+cardArr[jjj][y]->getOldNumber()&&!cardArr[x][y]->m_DstUsed)
                    {
                        cardArr[j][y]->m_SrcUsed=true;
                        cardArr[jj][y]->m_SrcUsed=true;
                        cardArr[jjj][y]->m_SrcUsed=true;
                        cardArr[x][y]->addSrcPos(j,y);
                        cardArr[x][y]->addSrcPos(jj,y);
                        cardArr[x][y]->addSrcPos(jjj,y);
                        cardArr[x][y]->m_DstUsed = true;
                    }
                }
            }
            
            for (int j=x; j>0; j--) {//two
                if(cardArr[j][y]->getOldNumber()>0&&!cardArr[j][y]->m_SrcUsed)
                {
                    int jj=-1;
                    for (int k=j-1; k>=0; k--) {
                        if(cardArr[k][y]->getOldNumber()>0&&!cardArr[k][y]->m_SrcUsed)
                        {
                            jj=k;
                            break;
                        }
                    }
                    if (jj==-1) {
                        break;
                    }
                    if(cardArr[x][y]->getNumber()==cardArr[j][y]->getOldNumber()+cardArr[jj][y]->getOldNumber()&&!cardArr[x][y]->m_DstUsed)
                    {
                        cardArr[j][y]->m_SrcUsed=true;
                        cardArr[jj][y]->m_SrcUsed=true;
                        cardArr[x][y]->addSrcPos(j,y);
                        cardArr[x][y]->addSrcPos(jj,y);
                        cardArr[x][y]->m_DstUsed = true;
                    }
                }
            }
            
            
            int i=-1;
            for (int j=x; j>=0; j--) {
                if (cardArr[j][y]->getOldNumber()>0&&!cardArr[j][y]->m_SrcUsed) {
                    i=j;
                    break;
                }
            }
            if(i>=0&&!cardArr[x][y]->m_DstUsed)
            {
                cardArr[i][y]->m_SrcUsed = true;
                cardArr[x][y]->addSrcPos(i,y);
                cardArr[x][y]->m_DstUsed = true;
            }
        
        }
    }
}
void Scene_2048::getSrcUp()
{
    this->clearUseds();
    for (int x = 0; x < m_RCount; x++)
    {
        for (int y = m_RCount-1; y >= 0; y--)
        {
            
            if(cardArr[x][y]->getNumber()==0) continue;
            
            if(cardArr[x][y]->getOldNumber()==cardArr[x][y]->getNumber()&&!cardArr[x][y]->m_SrcUsed)
            {
                cardArr[x][y]->m_SrcUsed = true;
                cardArr[x][y]->m_DstUsed = true;
                continue;
            }
            
            for (int j=y; j>1; j--) {//three
                if(cardArr[x][j]->getOldNumber()>0&&!cardArr[x][j]->m_SrcUsed)
                {
                    int jj=-1;
                    int jjj=-1;
                    for (int k=j-1; k>0; k--) {
                        if(cardArr[x][k]->getOldNumber()>0&&!cardArr[x][k]->m_SrcUsed)
                        {
                            jj=k;
                            for (int m=k-1; m>=0; m--) {
                                if(cardArr[x][m]->getOldNumber()>0&&!cardArr[x][m]->m_SrcUsed)
                                {
                                    jjj=m;
                                    break;
                                }
                            }
                            break;
                        }
                    }
                    if (jj==-1||jjj==-1) {
                        break;
                    }
                    if(cardArr[x][y]->getNumber()==cardArr[x][j]->getOldNumber()+cardArr[x][jj]->getOldNumber()+cardArr[x][jjj]->getOldNumber()&&!cardArr[x][y]->m_DstUsed)
                    {
                        cardArr[x][j]->m_SrcUsed=true;
                        cardArr[x][jj]->m_SrcUsed=true;
                        cardArr[x][jjj]->m_SrcUsed=true;
                        cardArr[x][y]->addSrcPos(x,j);
                        cardArr[x][y]->addSrcPos(x,jj);
                        cardArr[x][y]->addSrcPos(x,jjj);
                        cardArr[x][y]->m_DstUsed = true;
                    }
                }
            }
            
            for (int j=y; j>0; j--) {//two
                if(cardArr[x][j]->getOldNumber()>0&&!cardArr[x][j]->m_SrcUsed)
                {
                    int jj=-1;
                    for (int k=j-1; k>=0; k--) {
                        if(cardArr[x][k]->getOldNumber()>0&&!cardArr[x][k]->m_SrcUsed)
                        {
                            jj=k;
                            break;
                        }
                    }
                    if (jj==-1) {
                        break;
                    }
                    if(cardArr[x][y]->getNumber()==cardArr[x][j]->getOldNumber()+cardArr[x][jj]->getOldNumber()&&!cardArr[x][y]->m_DstUsed)
                    {
                        cardArr[x][j]->m_SrcUsed=true;
                        cardArr[x][jj]->m_SrcUsed=true;
                        cardArr[x][y]->addSrcPos(x,j);
                        cardArr[x][y]->addSrcPos(x,jj);
                        cardArr[x][y]->m_DstUsed = true;
                    }
                }
            }
            
            int i=-1;
            for (int j=y; j>=0; j--) {
                if (cardArr[x][j]->getOldNumber()>0&&!cardArr[x][j]->m_SrcUsed) {
                    i=j;
                    break;
                }
            }
            if(i>=0&&!cardArr[x][y]->m_DstUsed)
            {
                cardArr[x][i]->m_SrcUsed = true;
                cardArr[x][y]->addSrcPos(x,i);
                cardArr[x][y]->m_DstUsed = true;
            }
            
        }
    }
}
void Scene_2048::getSrcDown()
{
    this->clearUseds();
    for (int x = 0; x < m_RCount; x++)
    {
        for (int y = 0; y <m_RCount; y++)
        {
            
            if(cardArr[x][y]->getNumber()==0) continue;
            
            if(cardArr[x][y]->getOldNumber()==cardArr[x][y]->getNumber()&&!cardArr[x][y]->m_SrcUsed)
            {
                cardArr[x][y]->m_SrcUsed = true;
                cardArr[x][y]->m_DstUsed = true;
                continue;
            }
            
            for (int j=y; j<m_RCount-2; j++) {//three
                if(cardArr[x][j]->getOldNumber()>0&&!cardArr[x][j]->m_SrcUsed)
                {
                    int jj=-1;
                    int jjj=-1;
                    for (int k=j+1; k<m_RCount-1; k++) {
                        if(cardArr[x][k]->getOldNumber()>0&&!cardArr[x][k]->m_SrcUsed)
                        {
                            jj=k;
                            for (int m=k+1; m<m_RCount; m++) {
                                if(cardArr[x][m]->getOldNumber()>0&&!cardArr[x][m]->m_SrcUsed)
                                {
                                    jjj=m;
                                    break;
                                }
                            }
                            break;
                        }
                    }
                    if (jj==-1||jjj==-1) {
                        break;
                    }
                    if(cardArr[x][y]->getNumber()==cardArr[x][j]->getOldNumber()+cardArr[x][jj]->getOldNumber()+cardArr[x][jjj]->getOldNumber()&&!cardArr[x][y]->m_DstUsed)
                    {
                        
                        cardArr[x][j]->m_SrcUsed=true;
                        cardArr[x][jj]->m_SrcUsed=true;
                        cardArr[x][jjj]->m_SrcUsed=true;
                        cardArr[x][y]->addSrcPos(x,j);
                        cardArr[x][y]->addSrcPos(x,jj);
                        cardArr[x][y]->addSrcPos(x,jjj);
                        cardArr[x][y]->m_DstUsed = true;
                    }
                }
            }
            
            for (int j=y; j<m_RCount-1; j++) {//two
                if(cardArr[x][j]->getOldNumber()>0&&!cardArr[x][j]->m_SrcUsed)
                {
                    int jj=-1;
                    for (int k=j+1; k<m_RCount; k++) {
                        if(cardArr[x][k]->getOldNumber()>0&&!cardArr[x][k]->m_SrcUsed)
                        {
                            jj=k;
                            break;
                        }
                    }
                    if (jj==-1) {
                        break;
                    }
                    if(cardArr[x][y]->getNumber()==cardArr[x][j]->getOldNumber()+cardArr[x][jj]->getOldNumber()&&!cardArr[x][y]->m_DstUsed)
                    {
                        cardArr[x][j]->m_SrcUsed=true;
                        cardArr[x][jj]->m_SrcUsed=true;
                        cardArr[x][y]->addSrcPos(x,j);
                        cardArr[x][y]->addSrcPos(x,jj);
                        cardArr[x][y]->m_DstUsed = true;
                    }
                }
            }
            
            int i=-1;
            for (int j=y; j<m_RCount; j++) {
                if (cardArr[x][j]->getOldNumber()>0&&!cardArr[x][j]->m_SrcUsed) {
                    i=j;
                    break;
                }
            }
            if(i>=0&&!cardArr[x][y]->m_DstUsed)
            {
                cardArr[x][i]->m_SrcUsed = true;
                cardArr[x][y]->addSrcPos(x,i);
                cardArr[x][y]->m_DstUsed = true;
            }
        }
    }
}

void Scene_2048::doCheck()
{
	bool isGameOver = true;
	//check up down left right is the same with me
	for (int y = 0; y < m_RCount; y++)
	{
		for (int x = 0; x < m_RCount; x++)
		{
			if (cardArr[x][y]->getNumber() == 0 ||
				(x<m_RCount-1 && cardArr[x][y]->getNumber() == cardArr[x+1][y]->getNumber()) ||
				(x>0 && cardArr[x][y]->getNumber() == cardArr[x-1][y]->getNumber()) ||
				(y<m_RCount-1 && cardArr[x][y]->getNumber() == cardArr[x][y+1]->getNumber()) ||
				(y>0 && cardArr[x][y]->getNumber() == cardArr[x][y-1]->getNumber()) )
			{
				isGameOver = false;
			}
		}
	}
	if (isGameOver)
	{
		//restart
		Director::getInstance()->replaceScene(TransitionFade::create(1, Scene_2048::createScene()));
	}
}

bool Scene_2048::isMerge2048(CardSprite* a,CardSprite* b,int * merge_val)
{
    if(a->getNumber()==b->getNumber())
    {
        * merge_val = a->getNumber()*2;
        a->setNumber(0);
        b->setNumber(0);
        score+=*merge_val;
        SimpleAudioEngine::getInstance()->playEffect("r2048/effect_combine.mp3", false, 1.0, 1.0, 1.0);
        return true;
    }
    return false;
}


bool Scene_2048::doLeft()
{
	bool isMove = false;
	for (int y = 0; y < m_RCount; y++)
	{
		for (int x = 0; x < m_RCount; x++)
		{
			for (int x1 = x+1; x1<m_RCount; x1++)
			{
				if (cardArr[x1][y]->getNumber() > 0)
				{
                    int val;
					if (cardArr[x][y]->getNumber() <= 0)
					{
						cardArr[x][y]->setNumber(cardArr[x1][y]->getNumber());
						cardArr[x1][y]->setNumber(0);
						x--;
						isMove = true;
					}
					else if(isMerge2048(cardArr[x][y],cardArr[x1][y],&val))
					{
                        cardArr[x][y]->setNumber(val);
                        cardArr[x1][y]->setNumber(0);

                        //change score
                        score += cardArr[x][y]->getNumber();
                        isMove = true;
					}
					break;
				}
			}
		}
	}

	return isMove;
}

bool Scene_2048::doRight()
{

	bool isMove = false;
	for (int y = 0; y < m_RCount; y++)
	{
		for (int x = m_RCount-1; x >= 0; x--)
		{
			for (int x1 = x-1; x1>=0; x1--)
			{
				if (cardArr[x1][y]->getNumber() > 0)
				{
                    int val;
					if (cardArr[x][y]->getNumber() <= 0)
					{
						cardArr[x][y]->setNumber(cardArr[x1][y]->getNumber());
						cardArr[x1][y]->setNumber(0);
						x++;
						isMove = true;
					}
					else if(isMerge2048(cardArr[x][y],cardArr[x1][y],&val))
					{
						cardArr[x][y]->setNumber(val);
						cardArr[x1][y]->setNumber(0);
						//change score
						score += cardArr[x][y]->getNumber();
						isMove = true;
					}
					break;
				}
			}
		}
	}

	return isMove;
}


bool Scene_2048::doUp()
{
	bool isMove = false;
	for (int x = 0; x < m_RCount; x++)
	{
		for (int y = m_RCount-1; y >= 0; y--)
		{
			for (int y1 = y-1; y1>=0; y1--)
			{
				if (cardArr[x][y1]->getNumber() > 0)
				{
                    int val;
					if (cardArr[x][y]->getNumber() <= 0)
					{
						cardArr[x][y]->setNumber(cardArr[x][y1]->getNumber());
						cardArr[x][y1]->setNumber(0);
						y++;
						isMove = true;
					}
					else if(isMerge2048(cardArr[x][y],cardArr[x][y1],&val))
					{
						cardArr[x][y]->setNumber(val);
						cardArr[x][y1]->setNumber(0);
						//change score
						score += cardArr[x][y]->getNumber();
						isMove = true;
					}
					break;
				}
			}
		}
	}

	return isMove;
}

bool Scene_2048::doDown()
{
	bool isMove = false;
	for (int x = 0; x < m_RCount; x++)
	{
		for (int y = 0; y <m_RCount; y++)
		{
			for (int y1 = y+1; y1<m_RCount; y1++)
			{
				if (cardArr[x][y1]->getNumber() > 0)
				{
                    int val;
					if (cardArr[x][y]->getNumber() <= 0)
					{
						cardArr[x][y]->setNumber(cardArr[x][y1]->getNumber());
						cardArr[x][y1]->setNumber(0);
						y--;
						isMove = true;
					}
					else if(isMerge2048(cardArr[x][y], cardArr[x][y1],&val))
					{
						cardArr[x][y]->setNumber(val);
						cardArr[x][y1]->setNumber(0);
						//change score
						score += cardArr[x][y]->getNumber();
						isMove = true;
					}
					break;
				}
			}
		}
	}
	return isMove;
}

void Scene_2048::setScore(int score)
{
	cardNumberTTF->setString(__String::createWithFormat("Total:%i",score)->getCString());
    maxNumber->setString(__String::createWithFormat("Max:%i",getMaxCardNumber())->getCString());
}

CardSprite* Scene_2048::createCardNumber()
{
    int emptyCount=this->getEmptyCards();
    if (emptyCount==0) {
        CCLOG("GameOver");
        return NULL;
    }
    //srand(time(0));
    int i = CCRANDOM_0_1()*emptyCount;
    
    m_EmptyList[i]->setNumber(CCRANDOM_0_1()*10 < 1 ? 4 : 2);
    m_EmptyList[i]->swapBuffer();
    
    if (m_DispData!=nullptr&&!m_DispData->isLeaf()) {
        CardDispManager::getInstance()->resetLeafSetp(m_DispData);
    }
    m_DispData=CardDispManager::getInstance()->AddOneStep();
    this->saveStepData(m_DispData);
    
    return m_EmptyList[i];
}

unsigned int  Scene_2048::getEmptyCards()
{
    m_EmptyList.clear();
    for (int i=0; i<m_RCount; i++) {
        for (int j=0; j<m_RCount; j++) {
            if (cardArr[i][j]->getNumber()==0) {
                m_EmptyList.push_back(cardArr[i][j]);
            }
        }
    }
    return (unsigned int)m_EmptyList.size();
}

unsigned int Scene_2048::getMaxCardNumber()
{
    int number=0;
    for (int i=0; i<m_RCount; i++) {
        for (int j=0; j<m_RCount; j++) {
            if (number<cardArr[i][j]->getNumber()) {
                number=cardArr[i][j]->getNumber();
            }
        }
    }
    return number;
}





