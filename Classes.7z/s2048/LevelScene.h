#pragma once

#include "BaseScene.h"

class SettingScene : public BaseScene
{
public:
    CREATE_FUNC(SettingScene);
	virtual bool init();    
private:

    void onClick(Ref* ref,Widget::TouchEventType type);
    virtual string getWordsName();
    virtual int getRows();
    virtual int getCols();
};

class CellOverScene : public BaseScene
{
public:
    CREATE_FUNC(CellOverScene);
    virtual bool init();
private:
    
    void onClick(Ref* ref,Widget::TouchEventType type);
    virtual string getWordsName();
    virtual int getRows();
    virtual int getCols();
};

class SuccessScene : public BaseScene
{
public:
    CREATE_FUNC(SuccessScene);
    virtual bool init();
private:
    
    void onClick(Ref* ref,Widget::TouchEventType type);
    virtual string getWordsName();
    virtual int getRows();
    virtual int getCols();
};

class LevelSelect : public BaseScene
{
public:
    CREATE_FUNC(LevelSelect);
    virtual bool init();
private:
    
    void onClick(Ref* ref,Widget::TouchEventType type);
    virtual string getWordsName();
    virtual int getRows();
    virtual int getCols();
};

