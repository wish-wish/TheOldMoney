#pragma once

#include "CellScene.h"

class TerrainSceneMoney : public SceneMoneyInBa5
{
public:
    CREATE_FUNC(TerrainSceneMoney);
    TerrainSceneMoney();
    ~TerrainSceneMoney();
	virtual bool init();
private:
    virtual int checkTerrainCode(UserDirection ud,int x,int y);
    
    TerrainData m_ObjectList;
    TerrainData* m_EmptyList;
    
    TerrainData* m_TerrainList;
    
    void freeObjects();
    void generateObjects(int objsize=1);
    void clearTerrain();
    
    virtual string GetSceneName(){return "TerrainSceneMoney";};
};


class TerrainScene2048 : public Scene2048
{
public:
    CREATE_FUNC(TerrainScene2048);
    TerrainScene2048();
    ~TerrainScene2048();
    virtual bool init();
private:
    virtual int checkTerrainCode(UserDirection ud,int x,int y);
    
    TerrainData m_ObjectList;
    TerrainData* m_EmptyList;
    
    TerrainData* m_TerrainList;
    
    void freeObjects();
    void generateObjects(int objsize=1);
    void clearTerrain();
    
    virtual string GetSceneName(){return "TerrainScene2048";};
};

