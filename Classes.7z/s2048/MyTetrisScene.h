#pragma once

#include "cocos2d.h"
#include "s2048/TetrisCard.h"
#include "SimpleAudioEngine.h"
#include "ui/CocosGUI.h"
#include "cocostudio/CCSGUIReader.h"
#include "ActionModule.h"
#include "ArmatureModule.h"

USING_NS_CC;
using namespace CocosDenshion;
using namespace std;
using namespace ui;
using namespace cocostudio;

class TetrisBaseScene : public Scene
{
public:
	virtual bool init();

	bool onTouchBegan(cocos2d::Touch* touch, cocos2d::Event* event);
	void onTouchEnded(cocos2d::Touch* touch, cocos2d::Event* event);
    
    static Scene* createTNScene(float t,Scene* scene);
protected:
    float beginX,beginY,endX,endY;
        
    int m_CardSize;
    
    int m_RowCount;
    int m_ColCount;
    Rect m_BackgroundRect;
    TetrisCard *cardArr[30][40];

    void destoryCardSprite();
    void createCardSprite(Size size,Vec2 offset=Vec2::ZERO);
    virtual void createBlock(Vec2 pos)=0;
	
    virtual void onClick(Ref* ref,Widget::TouchEventType type)=0;
    virtual int getRows()=0;
    virtual int getCols()=0;
};

class MyTetrisScene : public TetrisBaseScene
{
public:
    CREATE_FUNC(MyTetrisScene);
    virtual bool init();
private:
    
    void onClick(Ref* ref,Widget::TouchEventType type);
    virtual int getRows();
    virtual int getCols();
    
    void RenderFunc(float delta);
    virtual void createBlock(Vec2 pos);
    
    Tetris_Block* m_block;
    
    void onNext(Ref* ref,Widget::TouchEventType type);
    void onPrior(Ref* ref,Widget::TouchEventType type);
    void onDown(Ref* ref,Widget::TouchEventType type);
    void onTurn(Ref* ref,Widget::TouchEventType type);
};



