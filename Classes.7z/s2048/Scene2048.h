#pragma once

#include "cocos2d.h"
#include "s2048/CardLayer.h"
#include "s2048/CardData.h"
#include "SimpleAudioEngine.h"
#include "ui/CocosGUI.h"
#include "editor-support/cocostudio/CCSGUIReader.h"

USING_NS_CC;
using namespace CocosDenshion;
using namespace std;
using namespace ui;
using namespace cocostudio;

#define AniTime 0.3
#define GridBrder 50

typedef vector<CardSprite*> CardList;

class Scene_2048 : public Scene
{
public:
	CREATE_FUNC(Scene_2048);
    static cocos2d::Scene* createScene();
	virtual bool init();
	//�����¼������ص�����
	bool onTouchBegan(cocos2d::Touch* touch, cocos2d::Event* event);
	void onTouchEnded(cocos2d::Touch* touch, cocos2d::Event* event);
    void changeRowCount(int count);
    unsigned int getEmptyCards();
    unsigned int getMaxCardNumber();
private:
    float beginX,beginY,endX,endY;
    int score;
    
    int m_CardSize;
    int m_RCount;
    bool m_isDirty;
    bool m_isMove;
    //���濨Ƭ��
    CardSprite *cardArr[maxRCount][maxRCount];
    //����
    
    //��ʾ�����ؼ�
    Label *cardNumberTTF;
    //�������������Ƭ
    
    Label *maxNumber;
    
    CardList m_EmptyList;
    bool m_isAnimating;
    
    CardDispData* m_DispData;
    
private:
	//������Ļ��С������Ƭ
    void destoryCardSprite();
    void createCardSprite(Size size,Vec2 offset=Vec2::ZERO);
	//˽�б��˼�¼������ʼ�ڽ���ʱ������
	
	//�󻬶�
	bool doLeft();
	//�һ���
	bool doRight();
	//�ϻ���
	bool doUp();
	//�»���
	bool doDown();
	//�����Ϸ�Ƿ����
	void doCheck();
    
    void doBackNumbers();
    void clearUseds();
    
    void doAnimations();
    void doDisplayNumbers();
    
    void getSrcLeft();
    void getSrcRight();
    void getSrcUp();
    void getSrcDown();
    
	//���÷���
	void setScore(int score);
    
    void removeCard(CardSprite* b);
    void swapCard(CardSprite* b);
    
protected:
    
    void logic2048();
    bool isMerge2048(CardSprite* a,CardSprite* b,int * merge_val);
    
    CardSprite* createCardNumber();
    
    void saveStepData(CardDispData* data);
    void showCardsNumber(CardDispData* data);
    
    void writeHistoryData();
private:
    void onNext(Ref* ref,Widget::TouchEventType type);
    void onPrior(Ref* ref,Widget::TouchEventType type);
    
};






