#pragma once

#include "cocos2d.h"
#include "Singleton.h"
#include "json/rapidjson.h"
#include "json/document.h"

USING_NS_CC;
using namespace std;
using namespace rapidjson;

#define maxRCount 15
#define defRow 6
const string dataLog="data_log.dat";
const string dataConfig="data_config.dat";
const string NumberFile="Number.json";


typedef vector<int> NumberList;

struct ChangeData
{
    int type;
    int srcx;
    int srcy;
    
    int dstx;
    int dsty;
};

typedef vector<ChangeData> ChangeDataList;

struct MergePos
{
    int x;
    int y;
};

typedef vector<MergePos*> TPosList;

struct MergeObj
{
    int dstx;
    int dsty;
    TPosList PosList;
};

typedef vector<MergeObj*> MergeList;

class CardDispData
{
public:
    explicit CardDispData(int Rows);
    ~CardDispData();
    void setData(int x,int y,int value);
    
    CardDispData* getPriorData();
    void setPriorData(CardDispData* data);
    
    CardDispData* getNextData();
    void setNextData(CardDispData* data);
    
    NumberList* getNumberList();
    ChangeDataList* GetChangeList();
    
    int GetNewPos();
    void SetNewPos(int value);
    int GetDirection();
    void SetDirection(int value);
    
    string toJson();
    Document& toJsonValue(Document& doc,Document::AllocatorType& allocator);
    void fromJson(string json);
    void formJsonValue(rapidjson::Value& array);
    bool isLeaf(){return m_NextData==nullptr;};
    
    MergeList* getMergeList();
    void clearMergeList(MergeList* list);
    
    bool isInMerge(MergeList* list,int x,int y);
    bool isInMergeFirst(MergeList* list,int x,int y);
    MergeObj* getMergeObj(MergeList* list,int x,int y);
    void setSceneName(string name){m_SceneName=name;};
    string getSceneName(){return m_SceneName;};
    
private:
    int m_Rows;
    int m_NewPos;
    int m_Direction;
    int m_CoundSeconds;
    string m_SceneName;
    
    NumberList m_NumberList;
    MergeList m_MergeList;
    
    ChangeDataList m_ChangeList;
    
    CardDispData* m_PriorData;
    CardDispData* m_NextData;
    
    char TerrainCode[maxRCount][maxRCount];
};

struct TransNumber
{
    int64_t Intnum;
    int64_t Max;
    string transName;
    string picture;
    string color;
    int64_t goal;
};

typedef vector<CardDispData*> StepList;

typedef vector<TransNumber*> NameList;

struct NameListObj
{
    string m_name;
    int64_t m_max;
    string m_unit;
    NameList m_List;
};

typedef map<string,NameListObj*> MapNameList;

struct MaxScore
{
    int m_Rows;
    string m_SceneName;
    
    int m_MaxScore;
    int m_MaxValue;
};

typedef vector<MaxScore*> MaxScoreList;

struct TerrainElem
{
    Vec2 Pos;
    int code;
    void *data;
};

typedef vector<TerrainElem*> TerrainData;

struct CardGameData
{
    int64_t m_Score;
    int64_t m_CountSeconds;
    bool  m_IsDefRowDirty;
    MaxScore m_MaxScore;
    
    StepList m_StepList;
    
    TerrainData m_Terrain;
    TerrainData m_EmptyList;
    
    TerrainData m_BorderEmptyList;//bian
    TerrainData m_CornerEmptyList;//jiao
    TerrainData m_InnerEmptyList;//limian
    TerrainData m_BorderOneEmptyList;//bianyi
    TerrainData m_InnerOneEmptyList;//limianyi
    TerrainData m_DuiJiaoEmptyList;//duijiao
    
    CardDispData* m_PlayData;// root linker for the steplist
};

class CardDispManager:public Singleton<CardDispManager>
{
public:
    CardDispManager();
    ~CardDispManager();
    
    CardDispData* AddOneStep();
    
    CardDispData* GetRootStep();
    CardDispData* GetRootStep(CardDispData* data);
    CardDispData* GetLeafStep();
    CardDispData* GetLeafStep(CardDispData* data);
    
    void RePlaySteps();
    
    void writeDataList();
    CardDispData* readDataList();

    void writeConfig();
    void readConfig();
    
    void clearData();
    void removeStep(CardDispData* data);
    CardDispData* resetLeafSetp(CardDispData* data);
    
    NameList* getTransList(string type);
    
    void loadTransJson();
    
    string getTransName(string name,int64_t num);
    bool isTransValueExists(string name,int num);
    int64_t getTransValue(string name,string val);
    string getTransPicture(string name,string val);
    string getTransPicture(string name,int val);
    string getTransUnit(string name);
    string getGoalStr(string name,int64_t num);
    
    TransNumber* getNextNumber(string name,int64_t num);
    TransNumber* getTransNumber(string name,int64_t num);
    
    void setMaxNumber(int num);
    int getMaxNumber();
    
    void setMaxScore(int num);
    int getMaxScore();
    
    void SetDefRows(int Rows);
    int  GetDefRows();
    
    void setCurrentScene(string name);
    string getCurrentScene();
    
    void setNewScene(string name);
    string getNewScene();
    
    void setIsSound(bool is);
    bool getIsSound();
    
    void setPriorType(int is);
    int getPriorType();
    
    void setIsReturn(bool is){m_IsBack=is;};
    bool getIsReturn(){return m_IsBack;};
    
    void freeTerrain();
    void generateTerrain();
    
    CardGameData* getGameData();
    void getEmptyList();
    
private:
    string  m_CurrentScene;
    string  m_NewScene;
    int m_DefRows;
    int64_t m_MaxNumber;
    int64_t m_MaxScore;
    bool m_IsSound;
    bool m_IsBack;
    int m_PriorType;
    
    CardGameData m_GameData;//game data
    
    MapNameList m_TransMap;
    MaxScoreList m_ScoreList;

    void removeStepFromList(CardDispData* data);
    void freeNameLists();
    void freeScoreList();
    
};

int CardRandom();




