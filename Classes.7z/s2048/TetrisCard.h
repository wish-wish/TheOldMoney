#pragma once

#include "cocos2d.h"
#include "CardData.h"
#include "ui/CocosGUI.h"

USING_NS_CC;
using namespace ui;
using namespace std;

#define BlockSize 4

typedef vector<Vec2> VecList;

class TetrisCard : public Layer
{
public:
    CREATE_FUNC(TetrisCard);
    ~TetrisCard();

    static TetrisCard* createTetrisCard(int number, int wight, int height, float CardSpriteX, float CardSpriteY);
	virtual bool init();
    
	int getNumber();
	void setNumber(int num);
    int getOldNumber();
    void setOldNumber(int num);
    int getDispNumber();
    void setDispNumber(int num);
    void swapBuffer();
    
    VecList m_SrcPos;
    bool m_SrcUsed;
    
    bool m_DstUsed;
    Vec2 m_DstPos;
    
    bool addSrcPos(int x,int y);
    void setGridPos(int x,int y);
    bool IsInSrcPos(int x,int y);
    
    Vec2 getPixelPos(){return m_PixelPos;};
    void setPixelPos(Vec2 p);
    Vec2 getGridPos(){return m_GridPos;};
    void setGridPos(Vec2 p){m_GridPos=p;};
    
    static Color3B GetNumberColor(int num);
    static Color3B GetBackColor(int num);
    
    LayerColor* getBackground();
    Rect& getRect(){return m_Rect;};
    
protected:
	int m_Number;
    int m_OldNumber;
    int m_DispNumber;
    
    Vec2 m_GridPos;
    Vec2 m_PixelPos;
    
    int m_Width;
    int m_Height;
    
    Rect m_Rect;
    
	void spriteInit(int number, int wight, int height, float CardSpriteX, float CardSpriteY);
    
	LayerColor *m_colorBackground;
    
    bool onTouchBegan(cocos2d::Touch* touch, cocos2d::Event* event);
    void onTouchEnded(cocos2d::Touch* touch, cocos2d::Event* event);
    void AddTouch();
    void RemoveToch();
    
    EventListenerTouchOneByOne* touchListener;
};

enum BlockType {
    btNone=-1
    ,btLetterI=0
    ,btLetterO=1
    ,btLetterS=2
    ,btLetterZ=3
    ,btLetterL=4
    ,btLetterJ=5
    ,btLetterT=6
    ,btLetterMax=7
};

enum BlockOrien
{
    boNone=-1
    ,boUp=0
    ,boDown=1
    ,boLeft=2
    ,boRight=3
    ,boMax=4
};

class Tetris_Block:public Layer
{
public:
    CREATE_FUNC(Tetris_Block);
    ~Tetris_Block();
    
    static Tetris_Block* createBlock(BlockType bt,BlockOrien bo,int whsize,Vec2 pos);
    
    virtual bool init();
    void blockInit(BlockType bt,BlockOrien bo,int whsize,Vec2 pos);
    
    void setBlockOrien(BlockOrien bo);
    
    void setPos(Vec2 pos){m_Pos=pos;};
    Vec2 getPos(){return m_Pos;};
    
    void setDestPos(Vec2 pos){m_DestPos=pos;};
    Vec2 getDestPos(){return m_DestPos;};
    
    void MoveDown();
    void MoveLeft();
    void MoveRight();
    void TurnOrien();
    
    void setBackgroundRect(Rect rect);
    Rect getBackgroundRect();
    void setBlockRect(Rect rect);
    Rect getBlockRect();
private:
    TetrisCard *cardArr[BlockSize];
    BlockType m_BlockType;
    BlockOrien m_BlockOrien;
    int m_WHSize;
    
    Vec2 m_Pos;
    Vec2 m_DestPos;
    
    Rect m_BlockRect;
    Rect m_BackgroundRect;
    
    
    void CreateBlockI();
    void CreateBlockJ();
    void CreateBlockL();
    void CreateBlockO();
    void CreateBlockS();
    void CreateBlockT();
    void CreateBlockZ();
    
    void CalcBlockRect();
};




