#include "CardLayer.h"
#include "CardData.h"
#include "cnTool.h"
#include "ActionModule.h"

USING_NS_CC;

CardSprite* CardSprite::createCardSprite(int number, int wight, int height, float CardSpriteX, float CardSpriteY,bool isTrans,string Trans)
{
	//�����Ǵ���һ���Զ��徫���࣬��ʽ�ܹ淶��
	CardSprite *card = new CardSprite();
	if (card && card->init())
	{
		card->autorelease();
		card->spriteInit(number,wight,height,CardSpriteX,CardSpriteY,isTrans,Trans);
		return card;
	}
	CC_SAFE_DELETE(card);

	return NULL;
}

CardSprite::~CardSprite()
{
    this->RemoveToch();
}

//����Ҳ�ǹ淶��
bool CardSprite::init()
{
	if (!Layer::init())
	{
		return false;
	}
    m_IsBackColor = true;
	return true;
}

int CardSprite::getOldNumber()
{
    return OldNumber;
}

void CardSprite::setOldNumber(int num)
{
    OldNumber=num;
}

int CardSprite::getDispNumber()
{
    return  DispNumber;
}

Color3B CardSprite::GetNumberColor(int num)
{
    return Color3B(0,0,255);
}

int CardSprite::GetStringFontSize(string name,int cell_width)
{
    int len=cnTools::GetStringWidth(name);
    int fsize = 0;
    switch (len) {
        case 1:
            fsize=100;
        break;
        case 2:
            fsize=85;
        break;
        case 3:
            fsize=75;
        break;
        case 4:
            fsize=60;
        break;
        case 5:
            fsize=45;
        break;
        case 6:
            fsize=35;
        break;
        case 7:
            fsize=30;
        break;
        case 8:
            fsize=25;
        break;
        default:
            fsize=20;
        break;
    }
    fsize=fsize*((float)cell_width/140.f);
    return fsize;
}

Color3B CardSprite::GetBackColor(int num)
{
    //�ж����ֵĴ�С��������ɫ
    if(num <= 0)
    {
        return Color3B(200,190,180);
    }
    else if (num>=100000000)
    {
        return Color3B(130,0,0);
    }
    else
    {
        switch (num) {
            case 2:
                return Color3B(240,130,220);
                break;
            case 4:
                return Color3B(140,230,180);
                break;
            case 8:
                return Color3B(240,230,140);
                break;
            case 16:
                return Color3B(140,230,100);
                break;
            case 32:
                return Color3B(240,230,60);
                break;
            case 64:
                return Color3B(140,230,40);
                break;
            case 128:
                return Color3B(140,130,0);
                break;
            case 256:
                return Color3B(240,190,120);
                break;
            case 512:
                return Color3B(140,150,220);
                break;
            case 1024:
                return Color3B(240,110,220);
                break;
            case 2048:
                return Color3B(140,70,220);
                break;
            case 4096:
                return Color3B(240,30,220);
                break;
            case 8192:
                return Color3B(140,0,220);
                break;
            case 16384:
                return Color3B(240,230,120);
                break;
            case 16384*2:
                return Color3B(200,130,220);
                break;
            case 16384*4:
                return Color3B(160,230,220);
                break;
            case 16384*8:
                return Color3B(120,130,220);
                break;
            case 16384*16:
                return Color3B(80,230,220);
                break;
            case 1:
                return Color3B(40,230,220);
                break;
            case 5:
                return Color3B(0,0,220);
                break;
            case 10:
                return Color3B(240,130,120);
                break;
            case 20:
                return Color3B(100,230,180);
                break;
            case 50:
                return Color3B(160,130,220);
                break;
            case 100:
                return Color3B(120,230,220);
                break;
            case 200:
                return Color3B(80,130,220);
                break;
            case 500:
                return Color3B(40,230,120);
                break;
            case 1000:
                return Color3B(0,130,220);
                break;
            case 2000:
                return Color3B(240,230,120);
                break;
            case 5000:
                return Color3B(200,130,120);
                break;
            case 10000:
                return Color3B(160,230,120);
                break;
            case 20000:
                return Color3B(120,130,120);
                break;
            case 50000:
                return Color3B(80,230,120);
                break;
            case 100000:
                return Color3B(40,130,120);
                break;
            case 200000:
                return Color3B(0,230,120);
                break;
            case 500000:
                return Color3B(120,200,120);
                break;
            case 1000000:
                return Color3B(120,180,220);
                break;
            case 2000000:
                return Color3B(120,160,120);
                break;
            case 5000000:
                return Color3B(120,140,220);
                break;
            case 10000000:
                return Color3B(120,120,120);
                break;
            case 20000000:
                return Color3B(120,100,220);
                break;
            case 50000000:
                return Color3B(120,80,120);
                break;
            case 100000000:
                return Color3B(120,60,220);
                break;
            case 200000000:
                return Color3B(120,40,120);
                break;
            case 500000000:
                return Color3B(120,20,220);
                break;
            case 1000000000:
                return Color3B(120,0,120);
                break;
            case 2000000000:
                return Color3B(120,0,60);
                break;
            default:
                return Color3B(0,88,88);
                break;
        }
    }
}

void CardSprite::ShowHintAnim()
{
    
    if (m_Sprite!=nullptr&&m_Sprite->isVisible()) {
        Sequence* seq=ActionModule::getInstance()->NewHintAnim(1.0,0.7*m_Sprite->getScale(),nullptr,m_Sprite->getScale());
        RepeatForever* rep=RepeatForever::create(seq);
        m_Sprite->runAction(rep);
    }
    else
    {
        Sequence* seq=ActionModule::getInstance()->NewHintAnim(1.0,0.7);
        RepeatForever* rep=RepeatForever::create(seq);
        colorBackground->runAction(rep);
    }
}

void CardSprite::StopHintAnim()
{
    if (m_Sprite!=nullptr&&m_Sprite->isVisible()) {
        m_Sprite->stopAllActions();
        m_Sprite->setScale(m_SpriteScale);
    }else
    {
        if(colorBackground!=nullptr)
        {
            colorBackground->stopAllActions();
            colorBackground->setScale(1.0f);
        }
    }
}

void CardSprite::clearTerrain()
{
    m_Number=0;
    m_DispStr="";
}


void CardSprite::dispPicture(TransNumber* number)
{
    if (number!=nullptr&&FileUtils::getInstance()->isFileExist(number->picture))
    {
        if (m_Sprite==nullptr) {
            m_Sprite=Sprite::create();
            this->addChild(m_Sprite, 5);
        }
        m_Sprite->setTexture(number->picture);
        m_Sprite->setVisible(true);
        Size size=m_Sprite->getContentSize();
        float scalex=m_Width/size.width;
        float scaley=m_Height/size.height;
        if (scalex<scaley)
        {
            m_SpriteScale=scalex;
        }
        else
        {
            m_SpriteScale=scaley;
        }
        m_Sprite->setPosition(m_Width/2,m_Height/2);
        m_Sprite->setScale(m_SpriteScale);
        labelCardNumber->setFontFillColor(Color3B::GREEN);
        labelCardNumber->setVisible(false);
        colorBackground->setVisible(false);
    }else
    {
        labelCardNumber->setFontFillColor(Color3B::WHITE);
        labelCardNumber->setVisible(true);
        this->hidePicture();
    }
}

void CardSprite::hidePicture()
{
    if(m_Sprite!=nullptr)
    {
        m_Sprite->setVisible(false);
        colorBackground->setVisible(true);
    }
}

void CardSprite::setDispNumber(int num)
{
    DispNumber = num;
    //������ʾ������
    this->RemoveToch();
    if (DispNumber<0)//terrain display
    {
        this->AddTouch();
        labelCardNumber->setString(m_DispStr);
        colorBackground->setColor(Color3B::BLACK);
        this->hidePicture();
    }else
    {
        if (DispNumber > 0)
        {
            string dispstr;
            if (!m_IsTrans) {
                dispstr=__String::createWithFormat("%i",DispNumber)->getCString();
            }
            else
            {
                dispstr=CardDispManager::getInstance()->getTransName(m_Trans, DispNumber);
            }
            m_DispStr = dispstr;
            labelCardNumber->setString(dispstr);
            TransNumber* tnum=CardDispManager::getInstance()->getTransNumber(m_Trans, DispNumber);
            this->dispPicture(tnum);
        }
        else
        {
            this->hidePicture();
            labelCardNumber->setString("");
            m_DispStr = "";
        }
        if (m_IsBackColor) {
            colorBackground->setColor(CardSprite::GetBackColor(DispNumber));
        }
    }
    labelCardNumber->setFontSize(GetStringFontSize(m_DispStr,m_Width));
}

//��ȡ����
int CardSprite::getNumber()
{
	return m_Number;
}

//��������
void CardSprite::setNumber(int num)
{
	m_Number = num;
}

void CardSprite::swapBuffer(float livets,CallFuncN* done)
{
    this->setDispNumber(getNumber());
    if (livets>0.01) {
        colorBackground->setScale(0.1);
        labelCardNumber->setScale(0.1);
        float timets=livets;
        if(timets<=0)
            timets=0.5;
        
        Sequence* seq=ActionModule::getInstance()->NewBornAnim(timets);
        labelCardNumber->runAction(seq);
        if (m_Sprite!=nullptr&&m_Sprite->isVisible()) {
            seq=ActionModule::getInstance()->NewBornAnim(timets,done,m_Sprite->getScale());
            m_Sprite->runAction(seq);
        }
        else
        {
            seq=ActionModule::getInstance()->NewBornAnim(timets,done);
            colorBackground->runAction(seq);
        }
        //this->setScale(0.1);
        //this->runAction(ScaleTo::create(0.5, 1));
    }
}

Vec2 CardSprite::GetCardPostion()
{
    return Point(m_PixelPosX,m_PixelPosY);// this->getPosition();
}

bool CardSprite::addSrcPos(int x,int y)
{
    if (IsInSrcPos(x, y)) {
        CCLOG("Pos already in list %d %d",x,y);
        return false;
    }
    m_SrcPos.push_back(Vec2(x,y));
    return true;
}

bool CardSprite::IsInSrcPos(int x,int y)
{
    for (int i=0; i<m_SrcPos.size(); i++) {
        int xx=m_SrcPos[i].x;
        int yy=m_SrcPos[i].y;
        if (xx==x&&yy==y) {
            return true;
        }
    }
    return false;
}

void CardSprite::setGridPos(int x,int y)
{
    m_GridPosX = x;
    m_GridPosY = y;
}

int CardSprite::getGridPosX()
{
    return  m_GridPosX;
}

int CardSprite::getGridPosY()
{
    return m_GridPosY;
}

LayerColor* CardSprite::getBackground()
{
    return colorBackground;
}

//��ʼ��
void CardSprite::spriteInit(int number, int wight, int height, float CardSpriteX, float CardSpriteY,bool isTrans,string Trans)
{
	//��ʼ������
    m_Sprite = nullptr;
	m_Number = number;
    m_IsTrans = isTrans;
    m_Trans = Trans;
    touchListener = nullptr;
    m_PixelPosX = CardSpriteX;
    m_PixelPosY = CardSpriteY;
    //this->AddTouch();
    m_DispStr = CardDispManager::getInstance()->getTransName(m_Trans, m_Number);
    if (m_Number<0) {
        m_DispStr = CardDispManager::getInstance()->getTransName("terrain", m_Number);
    }
	//���뿨Ƭ������ɫ
    int border = wight/40;
    m_Width = wight;
    m_Height = height;
    this->setPosition(Vec2(CardSpriteX,CardSpriteY));
    this->setContentSize(Size(wight,height));
    
    m_Rect = Rect(CardSpriteX+border, CardSpriteY+border, wight-border*2, height-border*2);
    
    LayerColor * broder=LayerColor::create(Color4B(200,190,180,255),wight-border*2,height-border*2);
    this->addChild(broder);
    broder->setPosition(Vec2(border,border));
    
    colorBackground = LayerColor::create(Color4B(200,190,180,255),wight-border*2,height-border*2);
	colorBackground->setPosition(Vec2(border,border));
    
    this->addChild(colorBackground);
    
    labelCardNumber = LabelTTF::create("","Consolas",100);
    labelCardNumber->setPosition(Point(colorBackground->getContentSize().width/2, colorBackground->getContentSize().height/2));
    labelCardNumber->setTag(8);
    this->addChild(labelCardNumber,10);
	
    this->afterInit(m_Number, m_Width, m_Height, CardSpriteX, CardSpriteY);
    

    
}

void CardSprite::AddTouch()
{
    //add touch listener
    if (touchListener==nullptr) {
        touchListener = EventListenerTouchOneByOne::create();
        touchListener->onTouchBegan = CC_CALLBACK_2(CardSprite::onTouchBegan, this);
        touchListener->onTouchEnded = CC_CALLBACK_2(CardSprite::onTouchEnded, this);
        _eventDispatcher->addEventListenerWithSceneGraphPriority(touchListener, this);
        //_eventDispatcher->addEventListenerWithFixedPriority(touchListener, 100);
    }
}
void CardSprite::RemoveToch()
{
    _eventDispatcher->removeEventListener(touchListener);
    touchListener=nullptr;
}


bool CardSprite::onTouchBegan(cocos2d::Touch* touch, cocos2d::Event* event)
{
    if (m_Rect.containsPoint(touch->getLocation())) {
        //CCLOG("Touch Sprite Began %s",m_DispStr.c_str());
        touchListener->setSwallowTouches(true);
    }else
    {
        touchListener->setSwallowTouches(false);
    }
    return true;
}

void CardSprite::onTouchEnded(cocos2d::Touch* touch, cocos2d::Event* event)
{
    if (m_Rect.containsPoint(touch->getLocation())) {
        //CCLOG("Touch Sprite Ended %s",m_DispStr.c_str());
    }
}

bool CardButton::init()
{
    if (!CardSprite::init())
    {
        return false;
    }
    return true;
}

Button* CardButton::getCardBtn()
{
    return m_CardBtn;
}

void CardButton::setText(string txt)
{
    m_DispStr = txt;
    m_CardBtn->setTitleText(txt);
}

string CardButton::getText()
{
    return m_DispStr;
}

CardButton* CardButton::createCardSprite(int num, int wight, int height, float CardSpriteX, float CardSpriteY,bool isTrans,string Trans)
{
    CardButton *button = new CardButton();
    if (button && button->init())
    {
        button->autorelease();
        button->spriteInit(num,wight,height,CardSpriteX,CardSpriteY,isTrans,Trans);
        return button;
    }
    CC_SAFE_DELETE(button);
    
    return NULL;
}

void CardButton::afterInit(int number, int wight, int height, float CardSpriteX, float CardSpriteY)
{
    m_CardBtn = Button::create();
    int border = wight/40;
    Size s=Size(wight-border*2,height-border*2);
    int fsize=this->GetStringFontSize(m_DispStr, s.width);
    m_CardBtn->setTitleFontName("Consolas");
    m_CardBtn->setTitleFontSize(fsize);
    m_CardBtn->setTitleText(m_DispStr);
    m_CardBtn->setPosition(Vec2(colorBackground->getContentSize().width/2, colorBackground->getContentSize().height/2));
    this->addChild(m_CardBtn,100);
    this->swapBuffer();
    colorBackground->setColor(Color3B(200,190,180));
}

