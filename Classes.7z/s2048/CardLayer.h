#pragma once

#include "cocos2d.h"
#include "CardData.h"
#include "ui/CocosGUI.h"

USING_NS_CC;
using namespace ui;
using namespace std;

#define GridBrder 50
#define EffectZorder 9999

typedef vector<Vec2> VecList;

class CardSprite : public Layer
{
public:
	static CardSprite* createCardSprite(int number, int wight, int height, float CardSpriteX, float CardSpriteY,bool isTrans=false,string Trans="");
	virtual bool init();
	CREATE_FUNC(CardSprite);
    ~CardSprite();
	//��ȡ����
	int getNumber();
	//��������
	void setNumber(int num);
    
    int getOldNumber();
    void setOldNumber(int num);
    
    int getDispNumber();
    void setDispNumber(int num);
    
    VecList m_SrcPos;
    bool m_SrcUsed;
    
    bool m_DstUsed;
    Vec2 m_DstPos;
    
    Vec2 GetCardPostion();
    void swapBuffer(float livets=0.0,CallFuncN* done=nullptr);
    
    bool addSrcPos(int x,int y);
    void setGridPos(int x,int y);
    bool IsInSrcPos(int x,int y);
    
    int getGridPosX();
    int getGridPosY();
    float getPixelsPosX(){return m_PixelPosX;};
    float getPixelsPosY(){return m_PixelPosY;};
    
    static Color3B GetNumberColor(int num);
    static Color3B GetBackColor(int num);
    static int GetStringFontSize(string name,int cell_width);
    
    LayerColor* getBackground();
    LabelTTF* getLabel(){return labelCardNumber;};
    Sprite*  getSprite(){return m_Sprite;};
    Rect& getRect(){return m_Rect;};
    
    void dispPicture(TransNumber* number);
    void hidePicture();
    
    void ShowHintAnim();
    void StopHintAnim();
    
    void clearTerrain();
    
protected:
	//��ʾ������
	int m_Number;
    int OldNumber;
    int DispNumber;
    
    int m_GridPosX;
    int m_GridPosY;
    int m_PixelPosX;
    int m_PixelPosY;
    
    int m_Width;
    int m_Height;
    
    bool m_IsTrans;
    bool m_IsBackColor;
    
    float m_SpriteScale;
    
    Sprite* m_Sprite;
    
    Rect m_Rect;
    
    string m_Trans;
    string m_DispStr;
    
    EventListenerTouchOneByOne* touchListener;
    
	//��ʼ��
	void spriteInit(int number, int wight, int height, float CardSpriteX, float CardSpriteY,bool isTrans,string Trans);
	//��ʾ���ֵĿؼ�
	LabelTTF *labelCardNumber;
	//����
	LayerColor *colorBackground;
    
    virtual void afterInit(int number, int wight, int height, float CardSpriteX, float CardSpriteY){};
    
    bool onTouchBegan(cocos2d::Touch* touch, cocos2d::Event* event);
    void onTouchEnded(cocos2d::Touch* touch, cocos2d::Event* event);

    void AddTouch();
    void RemoveToch();
};

class CardButton:public CardSprite
{
public:
    CREATE_FUNC(CardButton);
    
    virtual bool init();
    Button* getCardBtn();
    void setText(string txt);
    string getText();
    static CardButton* createCardSprite(int num, int wight, int height, float CardSpriteX, float CardSpriteY,bool isTrans=false,string Trans="");
private:
    Button* m_CardBtn;
    void afterInit(int number, int wight, int height, float CardSpriteX, float CardSpriteY);
};


