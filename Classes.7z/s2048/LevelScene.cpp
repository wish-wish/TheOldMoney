
#include "LevelScene.h"
#include "CellScene.h"
#include "TerrainScene.h"

USING_NS_CC;

bool SettingScene::init()
{
	if ( !BaseScene::init() )
	{
		return false;
	}
    if (CardDispManager::getInstance()->getGameData()->m_IsDefRowDirty) {
        cardArr[1][2]->getCardBtn()->setTitleText("");
        cardArr[1][2]->setNumber(0);
        cardArr[1][2]->swapBuffer();
    }
    for (int i=0; i<m_RowCount; i++) {
        for (int j=0; j<m_RowCount; j++) {
            string scenename=CardDispManager::getInstance()->getTransPicture(getWordsName(), cardArr[i][j]->getNumber());
            if(CardDispManager::getInstance()->getCurrentScene().compare(scenename)==0)
            {
                
                ArmatureModule::getInstance()->AddArmatureDataFile("effect/ui_effect.ExportJson");
                float x=cardArr[i][j]->getPixelsPosX();
                float y=cardArr[i][j]->getPixelsPosY();
                Rect rect(x,y,m_CardSize,m_CardSize);
                Armature* arm=ArmatureModule::getInstance()->PlayAroundDouble( "ui_effect", "lianhuafxeffect",rect,nullptr,2.0f,rtClockWise);
                this->addChild(arm,EffectZorder);
                this->addChild((Armature*)arm->getUserData(),EffectZorder);
                
                //arm=ArmatureModule::getInstance()->PlaySize("ui_effect", "fuliguangquan",rect);
                //this->addChild(arm,EffectZorder);
                
                /*
                ArmatureDataManager::getInstance()->addArmatureFileInfo("effect/ui_effect.ExportJson");
                
                Armature* armature = Armature::create("ui_effect");
                this->addChild(armature,1000);
                float x=cardArr[i][j]->getPixelsPosX();
                float y=cardArr[i][j]->getPixelsPosY();
                armature->setPosition(Vec2(x,y));
                Rect rect(x,y,m_CardSize,m_CardSize);
                Sequence* seq=ActionModule::getInstance()->NewAroundAction(rect,Vec2(x,y),nullptr,2);
                RepeatForever* rep=RepeatForever::create(seq);
                armature->runAction(rep);
                
                armature->getAnimation()->play("lianhuafxeffect");
                
                armature = Armature::create("ui_effect");
                this->addChild(armature,1000);
                armature->setPosition(Vec2(x+m_CardSize,y+m_CardSize));
                seq=ActionModule::getInstance()->NewAroundAction(rect,Vec2(x+m_CardSize,y+m_CardSize),nullptr,2);
                rep=RepeatForever::create(seq);
                armature->runAction(rep);
                
                armature->getAnimation()->play("lianhuafxeffect");
                */
            }
        }
    }
	return true;
}

void SettingScene::onClick(Ref* ref,Widget::TouchEventType type)
{
    if(type==Widget::TouchEventType::ENDED)
    {
        Button* btn=(Button*)ref;
        CardButton* b=(CardButton*)btn->getUserData();
        string sceneName=CardDispManager::getInstance()->getTransPicture(getWordsName(), b->getNumber());
        string currName = CardDispManager::getInstance()->getCurrentScene();
        if (sceneName.compare("")==0) {
            CCLOG("LevelScene::onClick sceneName is empty %d",b->getNumber());
        }
        else if (b->getNumber()==9||b->getNumber()==8) {
            if (b->getNumber()==9) {
                //TODO:About Scene
                CCLOG("LevelScene::onClick AboutScene Logic %d",b->getNumber());
            }
            else
            {
                CardDispManager::getInstance()->setIsReturn(true);
                Director::getInstance()->replaceScene(BaseScene::createTNScene(0.5,CellSceneBase::createScene(currName)));
            }
        }else
        {
            CardDispManager::getInstance()->setIsReturn(false);
            Director::getInstance()->replaceScene(BaseScene::createTNScene(0.5,CellSceneBase::createScene(sceneName)));
        }
    }
}

string SettingScene::getWordsName()
{
    return "level";
}

int SettingScene::getRows()
{
    return 3;
}

int SettingScene::getCols()
{
    return 3;
}


bool CellOverScene::init()
{
    if ( !BaseScene::init() )
    {
        return false;
    }
    
    Label* OverLabel = Label::create("", "Consolas", 90);
    Size visibleSize = Director::getInstance()->getVisibleSize();
    OverLabel->setPosition(Vec2(visibleSize.width/2, visibleSize.height/2+m_CardSize*m_RowCount/2+100));
    addChild(OverLabel);
    OverLabel->setString("游戏结束!");
    
    if(CardDispManager::getInstance()->getIsSound())
    {
        SimpleAudioEngine::getInstance()->playEffect("r2048/shibai.wav");
    }
    return true;
}

void CellOverScene::onClick(Ref* ref,Widget::TouchEventType type)
{
    if(type==Widget::TouchEventType::ENDED)
    {
        Button* btn=(Button*)ref;
        CardButton* b=(CardButton*)btn->getUserData();
        TransNumber* number=CardDispManager::getInstance()->getTransNumber(getWordsName(), b->getNumber());
        CardDispManager::getInstance()->setIsReturn(false);
        string sceneName=CardDispManager::getInstance()->getCurrentScene();
        switch (number->Intnum) {
            case 1:
            {
                Director::getInstance()->end();
#if (CC_TARGET_PLATFORM == CC_PLATFORM_WP8) || (CC_TARGET_PLATFORM == CC_PLATFORM_WINRT)
                MessageBox("You pressed the close button. Windows Store Apps do not implement a close button.","Alert");
                return;
#endif
                Director::getInstance()->end();
#if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
                exit(0);
#endif
            }
                break;
            case 2:
            {
                CardDispManager::getInstance()->setIsReturn(true);
                Director::getInstance()->replaceScene(BaseScene::createTNScene(0.5,CellSceneBase::createScene(sceneName)));
            }
                break;
            case 3:
            {
                Director::getInstance()->replaceScene(BaseScene::createTNScene(0.5,CellSceneBase::createScene(sceneName)));
            }
                break;
            case 4:
            {
                Director::getInstance()->replaceScene(BaseScene::createTNScene(0.5,SettingScene::create()));
            }
                break;
            default:
                break;
        }
    }
}

string CellOverScene::getWordsName()
{
    return "over";
}

int CellOverScene::getRows()
{
    return 2;
}

int CellOverScene::getCols()
{
    return 2;
}

bool SuccessScene::init()
{
    if ( !BaseScene::init() )
    {
        return false;
    }
    
    Label* OverLabel = Label::create("", "Consolas", 90);
    Size visibleSize = Director::getInstance()->getVisibleSize();
    OverLabel->setPosition(Vec2(visibleSize.width/2, visibleSize.height/2+m_CardSize*m_RowCount/2+100));
    addChild(OverLabel);
    OverLabel->setString("恭喜过关!");
    
    if(CardDispManager::getInstance()->getIsSound())
    {
        SimpleAudioEngine::getInstance()->playEffect("r2048/shibai.wav");
    }
    return true;
}

void SuccessScene::onClick(Ref* ref,Widget::TouchEventType type)
{
    if(type==Widget::TouchEventType::ENDED)
    {
        Button* btn=(Button*)ref;
        CardButton* b=(CardButton*)btn->getUserData();
        TransNumber* number=CardDispManager::getInstance()->getTransNumber(getWordsName(), b->getNumber());
        CardDispManager::getInstance()->setIsReturn(false);
        string sceneName=CardDispManager::getInstance()->getCurrentScene();
        switch (number->Intnum) {
            case 1:
            {
                CardDispManager::getInstance()->setIsReturn(true);
                Director::getInstance()->replaceScene(BaseScene::createTNScene(0.5,SettingScene::create()));
            }
            break;
            case 2:
            {
                Director::getInstance()->replaceScene(BaseScene::createTNScene(0.5,CellSceneBase::createScene(number->picture)));
            }
            break;
            case 3:
            {
                Director::getInstance()->replaceScene(BaseScene::createTNScene(0.5,CellSceneBase::createScene(sceneName)));
            }
            break;
            case 4:
            {
                CCLOG("TODO:下一关");
            }
            break;
            default:
            break;
        }
    }
}

string SuccessScene::getWordsName()
{
    return "success";
}

int SuccessScene::getRows()
{
    return 2;
}

int SuccessScene::getCols()
{
    return 2;
}

bool LevelSelect::init()
{
    if ( !BaseScene::init() )
    {
        return false;
    }
    
    Label* OverLabel = Label::create("", "Consolas", 90);
    Size visibleSize = Director::getInstance()->getVisibleSize();
    OverLabel->setPosition(Vec2(visibleSize.width/2, visibleSize.height/2+m_CardSize*m_RowCount/2+100));
    addChild(OverLabel);
    OverLabel->setString("关卡选择:");
    
    return true;
}

void LevelSelect::onClick(Ref* ref,Widget::TouchEventType type)
{
    if(type==Widget::TouchEventType::ENDED)
    {
        Button* btn=(Button*)ref;
        CardButton* b=(CardButton*)btn->getUserData();
        TransNumber* number=CardDispManager::getInstance()->getTransNumber(getWordsName(), b->getNumber());
        string sceneName=CardDispManager::getInstance()->getCurrentScene();
        CardDispManager::getInstance()->setIsReturn(false);
        if(number!=nullptr)
        {
            CCLOG("TODO:关卡设计");
            switch (number->Intnum) {
                case 1:
                {
                    
                }
                break;
                case 2:
                {
                    
                }
                break;
                case 3:
                {
                    
                }
                break;
                case 4:
                {
                    
                }
                break;
                default:
                break;
            }
        }
        else
        {
            CCLOG("TODO:关卡设计");
            Director::getInstance()->replaceScene(BaseScene::createTNScene(0.5,CellSceneBase::createScene(sceneName)));
        }
    }
}

string LevelSelect::getWordsName()
{
    return "level_select";
}

int LevelSelect::getRows()
{
    return 10;
}

int LevelSelect::getCols()
{
    return 10;
}


