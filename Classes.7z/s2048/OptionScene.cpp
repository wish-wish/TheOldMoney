
#include "OptionScene.h"
#include "CellScene.h"


USING_NS_CC;

bool OptionScene::init()
{
	if ( !BaseScene::init() )
	{
		return false;
	}
    
    Size visibleSize = Director::getInstance()->getVisibleSize();
    
    btnSound=Button::create();
    btnSound->setPosition(Vec2(visibleSize.width/2, visibleSize.height/2-m_RowCount*m_CardSize/2-100));
    if(CardDispManager::getInstance()->getIsSound())
        btnSound->setTitleText("Sound Off");
    else
        btnSound->setTitleText("Sound On");
    
    btnSound->setTitleFontSize(80);
    btnSound->addTouchEventListener(CC_CALLBACK_2(OptionScene::onSoundClick, this));
    addChild(btnSound);
    
    for (int i=0; i<m_RowCount; i++) {
        for (int j=0; j<m_RowCount; j++) {
            TransNumber* num=CardDispManager::getInstance()->getTransNumber(getWordsName(), cardArr[i][j]->getNumber());
            if (atoi(num->picture.c_str())==CardDispManager::getInstance()->GetDefRows()) {
                
                ArmatureModule::getInstance()->AddArmatureDataFile("effect/ui_effect.ExportJson");
                
                float x=cardArr[i][j]->getPixelsPosX();
                float y=cardArr[i][j]->getPixelsPosY();
                Rect rect(x,y,m_CardSize,m_CardSize);
                Armature* arm=ArmatureModule::getInstance()->PlayAroundDouble("ui_effect", "lianhuafxeffect",rect,nullptr,2.0f,rtClockWise);
                this->addChild(arm,EffectZorder);
                this->addChild((Armature*)arm->getUserData(),EffectZorder);
                
                /*
                ArmatureDataManager::getInstance()->addArmatureFileInfo("effect/ui_effect.ExportJson");
                Armature* armature = Armature::create("ui_effect");
                this->addChild(armature,1000);
                float x=cardArr[i][j]->getPixelsPosX();
                float y=cardArr[i][j]->getPixelsPosY();
                armature->setPosition(Vec2(x,y));
                Rect rect(x,y,m_CardSize,m_CardSize);
                Sequence* seq=ActionModule::getInstance()->NewAroundAction(rect,Vec2(x,y),nullptr,2);
                RepeatForever* rep=RepeatForever::create(seq);
                armature->runAction(rep);
                
                armature->getAnimation()->play("lianhuafxeffect");
                
                armature = Armature::create("ui_effect");
                this->addChild(armature,1000);
                armature->setPosition(Vec2(x+m_CardSize,y+m_CardSize));
                seq=ActionModule::getInstance()->NewAroundAction(rect,Vec2(x+m_CardSize,y+m_CardSize),nullptr,2);
                rep=RepeatForever::create(seq);
                armature->runAction(rep);
                
                armature->getAnimation()->play("lianhuafxeffect");
                */
            }
        }
    }
	return true;
}

void OptionScene::onSoundClick(Ref* ref,Widget::TouchEventType type)
{
    if(type==Widget::TouchEventType::ENDED)
    {
        CardDispManager::getInstance()->setIsSound(!CardDispManager::getInstance()->getIsSound());
        if(CardDispManager::getInstance()->getIsSound())
            btnSound->setTitleText("Sound Off");
        else
            btnSound->setTitleText("Sound On");
        btnSound->setTitleFontSize(80);
        btnSound->addTouchEventListener(CC_CALLBACK_2(OptionScene::onSoundClick, this));
    }
}

void OptionScene::onClick(Ref* ref,Widget::TouchEventType type)
{
    if(type==Widget::TouchEventType::ENDED)
    {
        Button* btn=(Button*)ref;
        CardButton* b=(CardButton*)btn->getUserData();
        if (b->getNumber()==5||b->getNumber()==0) {
        }else
        {
            string pic=CardDispManager::getInstance()->getTransPicture(getWordsName(), b->getNumber());
            int row=atoi(pic.c_str());
            CardDispManager::getInstance()->SetDefRows(row);
            CardDispManager::getInstance()->getGameData()->m_IsDefRowDirty = true;
            //Scene* s=CellSceneBase::createScene(CardDispManager::getInstance()->getCurrentScene());
            //Director::getInstance()->replaceScene(BaseScene::createTNScene(0.5,s));
        }
        
        Scene* s=CellSceneBase::createScene("SettingScene");
        Director::getInstance()->replaceScene(BaseScene::createTNScene(0.5,s));
    }
}

string OptionScene::getWordsName()
{
    return "option";
}

int OptionScene::getRows()
{
    return 3;
}

int OptionScene::getCols()
{
    return 3;
}


bool TestScene::init()
{
    if ( !BaseScene::init() )
    {
        return false;
    }
    
    for(int i=0;i<m_RowCount;i++)
    {
        for (int j=0; j<m_RowCount; j++) {
            string str=String::createWithFormat("%i:%i",i,j)->getCString();
            cardArr[i][j]->getLabel()->setString("");
            //cardArr[i][j]->getLabel()->setFontSize(CardSprite::GetStringFontSize(str,m_CardSize));
            cardArr[i][j]->getCardBtn()->setTitleText(str);
            cardArr[i][j]->getCardBtn()->setTitleFontSize(CardSprite::GetStringFontSize(str,m_CardSize));
        }
    }
    
    return true;
}

void TestScene::onClick(Ref* ref,Widget::TouchEventType type)
{
    if(type==Widget::TouchEventType::ENDED)
    {
        CCLOG("onClick");
    }
}

string TestScene::getWordsName()
{
    return "";
}

int TestScene::getRows()
{
    return 6;
}

int TestScene::getCols()
{
    return 6;
}






