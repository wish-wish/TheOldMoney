#pragma once

#include "BaseScene.h"

class OptionScene : public BaseScene
{
public:
    CREATE_FUNC(OptionScene);
    
	virtual bool init();
    
private:
	
    void onClick(Ref* ref,Widget::TouchEventType type);
    void onSoundClick(Ref* ref,Widget::TouchEventType type);
    
    virtual string getWordsName();
    virtual int getRows();
    virtual int getCols();
    Button* btnSound;
    Button* btnRotateEffect;
};


class TestScene : public BaseScene
{
public:
    CREATE_FUNC(TestScene);
    
    virtual bool init();
    
private:
    
    void onClick(Ref* ref,Widget::TouchEventType type);
    virtual string getWordsName();
    virtual int getRows();
    virtual int getCols();
};




