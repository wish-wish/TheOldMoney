
#include "TerrainScene.h"

USING_NS_CC;

bool TerrainSceneMoney::init()
{
    if ( !SceneMoneyInBa5::init() )
	{
		return false;
	}
    CardDispManager::getInstance()->setIsReturn(false);
	return true;
}

TerrainSceneMoney::TerrainSceneMoney()
{
    m_TerrainList = &CardDispManager::getInstance()->getGameData()->m_Terrain;
    m_EmptyList = &CardDispManager::getInstance()->getGameData()->m_InnerOneEmptyList;
    m_RCount = CardDispManager::getInstance()->GetDefRows();
    if (!CardDispManager::getInstance()->getIsReturn())
    {
        //CCLOG("clearTerrain");
        this->clearTerrain();
        this->generateObjects();
    }else
    {
        //CardDispManager::getInstance()->freeTerrain();
        //CardDispManager::getInstance()->generateTerrain();
    }
}

TerrainSceneMoney::~TerrainSceneMoney()
{
    //CCLOG("~TerrainSceneMoney");
    this->freeObjects();
}

int TerrainSceneMoney::checkTerrainCode(UserDirection ud,int x,int y)
{
    //TODO:Terrain Logic
    if(CardDispManager::getInstance()->getGameData()->m_Terrain[x*m_RCount+y]->code==0)
    {
        //CCLOG("%d,%d",x,y);
        return 0;
    }
    else
    {
        return CardDispManager::getInstance()->getGameData()->m_Terrain[x*m_RCount+y]->code;
    }
}

void TerrainSceneMoney::freeObjects()
{
    m_ObjectList.clear();
}

void TerrainSceneMoney::generateObjects(int objsize)
{
    for(int i=0;i<objsize;i++)
    {
        CardDispManager::getInstance()->getEmptyList();
        if(m_EmptyList->size()<=0) break;
        if(m_RCount>5&&CardRandom()%10>0)
        {
            int rand=CardRandom() % m_EmptyList->size();
            m_ObjectList.push_back((*m_EmptyList)[rand]);
            (*m_EmptyList)[rand]->code=CardRandom()%2-2;
        }
    }
    CCLOG("generateObjects");
}

void TerrainSceneMoney::clearTerrain()
{
    this->freeObjects();
    for (int i = 0; i < m_RCount; i++)
    {
        for (int j = 0; j < m_RCount; j++)
        {
            int index=i*m_RCount+j;
            if((CardDispManager::getInstance()->getGameData()->m_Terrain[index]->code<0)&&cardArr[i][j]!=nullptr)
            {
                //TODO:clear sprite
                //cardArr[i][j]->clearTerrain();
            }
            CardDispManager::getInstance()->getGameData()->m_Terrain[index]->code=0;
        }
    }
}

bool TerrainScene2048::init()
{
    if ( !Scene2048::init() )
    {
        return false;
    }
    CardDispManager::getInstance()->setIsReturn(false);
    return true;
}

TerrainScene2048::TerrainScene2048()
{
    m_TerrainList = &CardDispManager::getInstance()->getGameData()->m_Terrain;
    m_EmptyList = &CardDispManager::getInstance()->getGameData()->m_InnerOneEmptyList;
    m_RCount = CardDispManager::getInstance()->GetDefRows();
    if (!CardDispManager::getInstance()->getIsReturn())
    {
        //CCLOG("clearTerrain");
        this->clearTerrain();
        this->generateObjects();
    }else
    {
        //CardDispManager::getInstance()->freeTerrain();
        //CardDispManager::getInstance()->generateTerrain();
    }
}

TerrainScene2048::~TerrainScene2048()
{
    //CCLOG("~TerrainSceneMoney");
    this->freeObjects();
}

int TerrainScene2048::checkTerrainCode(UserDirection ud,int x,int y)
{
    //TODO:Terrain Logic
    if(CardDispManager::getInstance()->getGameData()->m_Terrain[x*m_RCount+y]->code==0)
    {
        //CCLOG("%d,%d",x,y);
        return 0;
    }
    else
    {
        return CardDispManager::getInstance()->getGameData()->m_Terrain[x*m_RCount+y]->code;
    }
}

void TerrainScene2048::freeObjects()
{
    m_ObjectList.clear();
}

void TerrainScene2048::generateObjects(int objsize)
{
    for(int i=0;i<objsize;i++)
    {
        CardDispManager::getInstance()->getEmptyList();
        if(m_EmptyList->size()<=0) break;
        if(m_RCount>4&&CardRandom()%10>0)
        {
            int rand=CardRandom() % m_EmptyList->size();
            m_ObjectList.push_back((*m_EmptyList)[rand]);
            (*m_EmptyList)[rand]->code=CardRandom()%2-2;
        }
    }
    CCLOG("generateObjects");
}

void TerrainScene2048::clearTerrain()
{
    this->freeObjects();
    for (int i = 0; i < m_RCount; i++)
    {
        for (int j = 0; j < m_RCount; j++)
        {
            int index=i*m_RCount+j;
            if((CardDispManager::getInstance()->getGameData()->m_Terrain[index]->code<0)&&cardArr[i][j]!=nullptr)
            {
                //TODO:clear sprite
                //cardArr[i][j]->clearTerrain();
            }
            CardDispManager::getInstance()->getGameData()->m_Terrain[index]->code=0;
        }
    }
}

