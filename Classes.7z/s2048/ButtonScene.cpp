
#include "ButtonScene.h"
#include "CellScene.h"

USING_NS_CC;


Scene* ButtonBaseScene::createTNScene(float t,Scene* scene)
{
    int randomint=CardRandom()%25;
    Scene* finalscene=scene;
    switch (randomint) {
        case 0:
            finalscene= TransitionCrossFade::create(t, scene);
            break;
        case 1:
            finalscene= TransitionRotoZoom::create(t, scene);
            break;
        case 2:
            finalscene= TransitionJumpZoom::create(t, scene);
            break;
        case 3:
            finalscene= TransitionMoveInL::create(t, scene);
            break;
        case 4:
            finalscene= TransitionMoveInR::create(t, scene);
            break;
        case 5:
            finalscene= TransitionMoveInT::create(t, scene);
            break;
        case 6:
            finalscene= TransitionMoveInB::create(t, scene);
            break;
        case 7:
            finalscene= TransitionSlideInL::create(t, scene);
            break;
        case 8:
            finalscene= TransitionSlideInR::create(t, scene);
            break;
        case 9:
            finalscene= TransitionSlideInB::create(t, scene);
            break;
        case 10:
            finalscene= TransitionSlideInT::create(t, scene);
            break;
        case 11:
            finalscene= TransitionShrinkGrow::create(t, scene);
            break;
        case 12:
            finalscene= TransitionFlipX::create(t, scene);
            break;
        case 13:
            finalscene= TransitionFlipY::create(t, scene);
            break;
        case 14:
            finalscene= TransitionFlipAngular::create(t, scene);
            break;
        case 15:
            finalscene= TransitionZoomFlipX::create(t, scene);
            break;
        case 16:
            finalscene= TransitionZoomFlipAngular::create(t, scene);
            break;
        case 17:
            finalscene= TransitionFade::create(t, scene);
            break;
        case 18:
            finalscene= TransitionCrossFade::create(t, scene);
            break;
        case 19:
            finalscene= TransitionTurnOffTiles::create(t, scene);
            break;
        case 20:
            finalscene= TransitionSplitCols::create(t, scene);
            break;
        case 21:
            finalscene= TransitionFadeTR::create(t, scene);
            break;
        case 22:
            finalscene= TransitionFadeBL::create(t, scene);
            break;
        case 23:
            finalscene= TransitionFadeUp::create(t, scene);
            break;
        case 24:
            finalscene= TransitionFadeDown::create(t, scene);
            break;
/*
        case 25:
            finalscene= TransitionSceneOriented::create(t, scene,TransitionScene::Orientation::LEFT_OVER);
            break;
        case 26:
            finalscene= TransitionSceneOriented::create(t, scene,TransitionScene::Orientation::RIGHT_OVER);
            break;
        case 27:
            finalscene= TransitionSceneOriented::create(t, scene,TransitionScene::Orientation::DOWN_OVER);
            break;
        case 28:
            finalscene= TransitionSceneOriented::create(t, scene,TransitionScene::Orientation::UP_OVER);
            break;
*/
        default:
            finalscene= TransitionCrossFade::create(t, scene);
            break;
    }
    return finalscene;
}

bool ButtonBaseScene::init()
{
	if ( !Scene::init() )
	{
		return false;
	}
	Size visibleSize = Director::getInstance()->getVisibleSize();
	Point origin = Director::getInstance()->getVisibleOrigin();

	//add touch listener
	auto touchListener = EventListenerTouchOneByOne::create();
	touchListener->onTouchBegan = CC_CALLBACK_2(ButtonBaseScene::onTouchBegan, this);
	touchListener->onTouchEnded = CC_CALLBACK_2(ButtonBaseScene::onTouchEnded, this);
	_eventDispatcher->addEventListenerWithSceneGraphPriority(touchListener, this);

	//add background
	auto layerColorBG = LayerColor::create(Color4B(180, 170, 160, 255));
	this->addChild(layerColorBG);
    
    m_RowCount = getRows();
    m_ColCount = getCols();
    
    visibleSize.height=visibleSize.height-200;
    visibleSize.width=visibleSize.width-20;
	createCardSprite(visibleSize,Vec2(0,0));
	return true;
}

//create card with screen size
void ButtonBaseScene::createCardSprite(Size size,Vec2 offset)
{
    m_CardWidth = size.width/m_ColCount;
    m_CardHeight = size.height/m_RowCount;
    
	//绘制出nXn的单元格
    CCLOG("createCardSprite %d * %d",m_RowCount,m_RowCount);
	for (int i = 0; i < m_ColCount; i++)
	{
		for (int j = 0; j < m_RowCount; j++)
		{
			//need screen pixels match
            Size vs=Director::getInstance()->getVisibleSize();
            int x=vs.width/2-(m_CardWidth*m_ColCount)/2+m_CardWidth*i+offset.x;
            int y=vs.height/2-(m_CardHeight*m_RowCount)/2+m_CardHeight*j+offset.y;
			CardButton *card = CardButton::createCardSprite(i*m_ColCount+j+1, m_CardWidth, m_CardHeight, x,y ,true,getWordsName());
            card->setGridPos(i, j);
			cardArr[i][j] = card;
			addChild(card);
            card->getCardBtn()->setUserData((void*)card);
            card->getCardBtn()->addTouchEventListener(CC_CALLBACK_2(ButtonBaseScene::onClick, this));
		}
	}
}



bool ButtonBaseScene::onTouchBegan(Touch* touch, Event* event)
{
	Vec2 beginTouch = touch->getLocation();  //获取OpenGL坐标，以左下角为原点
	beginX = beginTouch.x;
	beginY = beginTouch.y;
	return true;
}

void ButtonBaseScene::onTouchEnded(Touch* touch, Event* event)
{
	Vec2 endTouch = touch->getLocation();  //获取OpenGL坐标，以左下角为原点
}


bool ButtonScene::init()
{
    if ( !ButtonBaseScene::init() )
    {
        return false;
    }
    
    for(int i=0;i<m_ColCount;i++)
    {
        for (int j=0; j<m_RowCount; j++) {
            string str=String::createWithFormat("%i:%i",i,j)->getCString();
            cardArr[i][j]->getLabel()->setString("");
            cardArr[i][j]->getCardBtn()->setTitleText(str);
            cardArr[i][j]->getCardBtn()->setTitleFontSize(CardSprite::GetStringFontSize(str,m_CardWidth));
        }
    }
    return true;
}

void ButtonScene::onClick(Ref* ref,Widget::TouchEventType type)
{
    if(type==Widget::TouchEventType::ENDED)
    {
        CCLOG("onClick");
    }
}

string ButtonScene::getWordsName()
{
    return "";
}

int ButtonScene::getRows()
{
    return 8;
}

int ButtonScene::getCols()
{
    return 6;
}




