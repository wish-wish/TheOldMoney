
#include "MyTetrisScene.h"
#include "CellScene.h"

USING_NS_CC;


Scene* TetrisBaseScene::createTNScene(float t,Scene* scene)
{
    int randomint=CardRandom()%25;
    Scene* finalscene=scene;
    switch (randomint) {
        case 0:
            finalscene= TransitionCrossFade::create(t, scene);
            break;
        case 1:
            finalscene= TransitionRotoZoom::create(t, scene);
            break;
        case 2:
            finalscene= TransitionJumpZoom::create(t, scene);
            break;
        case 3:
            finalscene= TransitionMoveInL::create(t, scene);
            break;
        case 4:
            finalscene= TransitionMoveInR::create(t, scene);
            break;
        case 5:
            finalscene= TransitionMoveInT::create(t, scene);
            break;
        case 6:
            finalscene= TransitionMoveInB::create(t, scene);
            break;
        case 7:
            finalscene= TransitionSlideInL::create(t, scene);
            break;
        case 8:
            finalscene= TransitionSlideInR::create(t, scene);
            break;
        case 9:
            finalscene= TransitionSlideInB::create(t, scene);
            break;
        case 10:
            finalscene= TransitionSlideInT::create(t, scene);
            break;
        case 11:
            finalscene= TransitionShrinkGrow::create(t, scene);
            break;
        case 12:
            finalscene= TransitionFlipX::create(t, scene);
            break;
        case 13:
            finalscene= TransitionFlipY::create(t, scene);
            break;
        case 14:
            finalscene= TransitionFlipAngular::create(t, scene);
            break;
        case 15:
            finalscene= TransitionZoomFlipX::create(t, scene);
            break;
        case 16:
            finalscene= TransitionZoomFlipAngular::create(t, scene);
            break;
        case 17:
            finalscene= TransitionFade::create(t, scene);
            break;
        case 18:
            finalscene= TransitionCrossFade::create(t, scene);
            break;
        case 19:
            finalscene= TransitionTurnOffTiles::create(t, scene);
            break;
        case 20:
            finalscene= TransitionSplitCols::create(t, scene);
            break;
        case 21:
            finalscene= TransitionFadeTR::create(t, scene);
            break;
        case 22:
            finalscene= TransitionFadeBL::create(t, scene);
            break;
        case 23:
            finalscene= TransitionFadeUp::create(t, scene);
            break;
        case 24:
            finalscene= TransitionFadeDown::create(t, scene);
            break;
/*
        case 25:
            finalscene= TransitionSceneOriented::create(t, scene,TransitionScene::Orientation::LEFT_OVER);
            break;
        case 26:
            finalscene= TransitionSceneOriented::create(t, scene,TransitionScene::Orientation::RIGHT_OVER);
            break;
        case 27:
            finalscene= TransitionSceneOriented::create(t, scene,TransitionScene::Orientation::DOWN_OVER);
            break;
        case 28:
            finalscene= TransitionSceneOriented::create(t, scene,TransitionScene::Orientation::UP_OVER);
            break;
*/
        default:
            finalscene= TransitionCrossFade::create(t, scene);
            break;
    }
    return finalscene;
}

bool TetrisBaseScene::init()
{
	if ( !Scene::init() )
	{
		return false;
	}
	Size visibleSize = Director::getInstance()->getVisibleSize();
	Point origin = Director::getInstance()->getVisibleOrigin();

	//add touch listener
	auto touchListener = EventListenerTouchOneByOne::create();
	touchListener->onTouchBegan = CC_CALLBACK_2(TetrisBaseScene::onTouchBegan, this);
	touchListener->onTouchEnded = CC_CALLBACK_2(TetrisBaseScene::onTouchEnded, this);
	_eventDispatcher->addEventListenerWithSceneGraphPriority(touchListener, this);

	//add background
	auto layerColorBG = LayerColor::create(Color4B(180, 170, 160, 255));
	this->addChild(layerColorBG);
    
    m_RowCount = getRows();
    m_ColCount = getCols();
    
    visibleSize.height=visibleSize.height-200;
    visibleSize.width=visibleSize.width-20;
	createCardSprite(visibleSize,Vec2(0,0));
    createBlock(Vec2(0,0));
    
	return true;
}

void TetrisBaseScene::createCardSprite(Size size,Vec2 offset)
{
    int Width = size.width/m_ColCount;
    int Height = size.height/m_RowCount;
    
    m_CardSize = Width<Height?Width:Height;
    
	//绘制出nXn的单元格
    CCLOG("createCardSprite %d * %d",m_RowCount,m_RowCount);
	for (int i = 0; i < m_ColCount; i++)
	{
		for (int j = 0; j < m_RowCount; j++)
		{
            Size vs=Director::getInstance()->getVisibleSize();
            int x=vs.width/2-(m_CardSize*m_ColCount)/2+m_CardSize*i+offset.x;
            int y=vs.height/2-(m_CardSize*m_RowCount)/2+m_CardSize*j+offset.y;
			TetrisCard *card = TetrisCard::createTetrisCard(j*m_ColCount+i+2, m_CardSize, m_CardSize, x,y);
            card->setGridPos(Vec2(i, j));
			cardArr[i][j] = card;
			addChild(card);
            card->swapBuffer();
		}
	}
    m_BackgroundRect = Rect(cardArr[0][0]->getPixelPos().x,cardArr[0][0]->getPixelPos().y,m_ColCount*m_CardSize,m_RowCount*m_CardSize);
}

bool TetrisBaseScene::onTouchBegan(Touch* touch, Event* event)
{
	Vec2 beginTouch = touch->getLocation();
	beginX = beginTouch.x;
	beginY = beginTouch.y;
	return true;
}

void TetrisBaseScene::onTouchEnded(Touch* touch, Event* event)
{
	Vec2 endTouch = touch->getLocation();
}


bool MyTetrisScene::init()
{
    if ( !TetrisBaseScene::init() )
    {
        return false;
    }
    
    Size visibleSize = Director::getInstance()->getVisibleSize();
    
    
    
    Button* btnPrior=Button::create();
    btnPrior->setPosition(Vec2(100, 80));
    btnPrior->setTitleText("Left");
    btnPrior->setTitleFontSize(40);
    btnPrior->addTouchEventListener(CC_CALLBACK_2(MyTetrisScene::onPrior, this));
    addChild(btnPrior);
    
    Button* btnDown=Button::create();
    btnDown->setPosition(Vec2(visibleSize.width/2-100, 80));
    btnDown->setTitleText("Down");
    btnDown->setTitleFontSize(40);
    btnDown->addTouchEventListener(CC_CALLBACK_2(MyTetrisScene::onDown, this));
    addChild(btnDown);
    
    Button* btnTurn=Button::create();
    btnTurn->setPosition(Vec2(visibleSize.width/2+100, 80));
    btnTurn->setTitleText("Turn");
    btnTurn->setTitleFontSize(40);
    btnTurn->addTouchEventListener(CC_CALLBACK_2(MyTetrisScene::onTurn, this));
    addChild(btnTurn);
    
    Button* btnNext=Button::create();
    btnNext->setPosition(Vec2(visibleSize.width-100, 80));
    btnNext->setTitleText("Right");
    btnNext->setTitleFontSize(40);
    btnNext->addTouchEventListener(CC_CALLBACK_2(MyTetrisScene::onNext, this));
    addChild(btnNext);

    if(!isScheduled(schedule_selector(MyTetrisScene::RenderFunc))) {
        schedule(schedule_selector(MyTetrisScene::RenderFunc), 1.0);
    }
    return true;
}

void MyTetrisScene::onClick(Ref* ref,Widget::TouchEventType type)
{
    if(type==Widget::TouchEventType::ENDED)
    {
        CCLOG("onClick");
    }
}

int MyTetrisScene::getRows()
{
    return 30;
}

int MyTetrisScene::getCols()
{
    return 18;
}

void MyTetrisScene::RenderFunc(float delta)
{
    m_block->MoveDown();
}

void MyTetrisScene::createBlock(Vec2 pos)
{
    int boOren=CardRandom()%boMax;
    int btType=(CardRandom()/2)%btLetterMax;
    m_block=Tetris_Block::createBlock((BlockType)btType, (BlockOrien)boOren, m_CardSize, cardArr[9][29]->getPixelPos());
    m_block->setBackgroundRect(m_BackgroundRect);
    addChild(m_block);
}

void MyTetrisScene::onNext(Ref* ref,Widget::TouchEventType type)
{
    m_block->MoveRight();
}
void MyTetrisScene::onPrior(Ref* ref,Widget::TouchEventType type)
{
    m_block->MoveLeft();
}
void MyTetrisScene::onDown(Ref* ref,Widget::TouchEventType type)
{
    m_block->MoveDown();
}

void MyTetrisScene::onTurn(Ref* ref,Widget::TouchEventType type)
{
    m_block->TurnOrien();
}




