
#include "TetrisCard.h"

USING_NS_CC;

TetrisCard* TetrisCard::createTetrisCard(int number, int wight, int height, float TetrisCardX, float TetrisCardY)
{
    TetrisCard *card = new TetrisCard();
	if (card && card->init())
	{
		card->autorelease();
		card->spriteInit(number,wight,height,TetrisCardX,TetrisCardY);
		return card;
	}
	CC_SAFE_DELETE(card);

	return NULL;
}

TetrisCard::~TetrisCard()
{
    this->RemoveToch();
}

bool TetrisCard::init()
{
	if (!Layer::init())
	{
		return false;
	}
	return true;
}

Color3B TetrisCard::GetNumberColor(int num)
{
    return Color3B(0,0,255);
}

Color3B TetrisCard::GetBackColor(int num)
{
    switch (num) {
        case 0:
            return Color3B(200,190,180);
            break;
        case 1:
            return Color3B(40,230,220);
            break;
        default:
            return Color3B(0,88,88);
            break;
    }
}

int TetrisCard::getOldNumber()
{
    return m_OldNumber;
}

void TetrisCard::setOldNumber(int num)
{
    m_OldNumber=num;
}

int TetrisCard::getDispNumber()
{
    return  m_DispNumber;
}

void TetrisCard::setDispNumber(int num)
{
    m_DispNumber = num;
    if (m_DispNumber<0)
    {
        m_colorBackground->setColor(Color3B::BLACK);
    }else
    {
        m_colorBackground->setColor(TetrisCard::GetBackColor(m_DispNumber));
    }
}

int TetrisCard::getNumber()
{
	return m_Number;
}

void TetrisCard::setNumber(int num)
{
	m_Number = num;
}

void TetrisCard::swapBuffer()
{
    this->setDispNumber(getNumber());
}

bool TetrisCard::addSrcPos(int x,int y)
{
    if (IsInSrcPos(x, y)) {
        CCLOG("Pos already in list %d %d",x,y);
        return false;
    }
    m_SrcPos.push_back(Vec2(x,y));
    return true;
}

bool TetrisCard::IsInSrcPos(int x,int y)
{
    for (int i=0; i<m_SrcPos.size(); i++) {
        int xx=m_SrcPos[i].x;
        int yy=m_SrcPos[i].y;
        if (xx==x&&yy==y) {
            return true;
        }
    }
    return false;
}

void TetrisCard::setPixelPos(Vec2 p)
{
    m_PixelPos=p;
    this->setPosition(m_PixelPos);
};

LayerColor* TetrisCard::getBackground()
{
    return m_colorBackground;
}

void TetrisCard::spriteInit(int number, int wight, int height, float TetrisCardX, float TetrisCardY)
{
	m_Number = number;
    touchListener = nullptr;
    m_PixelPos=Vec2(TetrisCardX,TetrisCardY);
    int border = wight/40;
    m_Width = wight;
    m_Height = height;
    this->setPosition(m_PixelPos);
    this->setContentSize(Size(wight,height));
    
    m_Rect = Rect(TetrisCardX+border, TetrisCardY+border, wight-border*2, height-border*2);
    
    //LayerColor * broder=LayerColor::create(Color4B(200,190,180,255),wight,height);
    //this->addChild(broder);
    //broder->setPosition(Vec2(0,0));
    
    m_colorBackground = LayerColor::create(Color4B(200,190,180,255),wight-border*2,height-border*2);
	m_colorBackground->setPosition(Vec2(border,border));
    //this->setColor(Color3B(200,190,180));
    this->addChild(m_colorBackground);
}

void TetrisCard::AddTouch()
{
    //add touch listener
    if (touchListener==nullptr) {
        touchListener = EventListenerTouchOneByOne::create();
        touchListener->onTouchBegan = CC_CALLBACK_2(TetrisCard::onTouchBegan, this);
        touchListener->onTouchEnded = CC_CALLBACK_2(TetrisCard::onTouchEnded, this);
        _eventDispatcher->addEventListenerWithSceneGraphPriority(touchListener, this);
        //_eventDispatcher->addEventListenerWithFixedPriority(touchListener, 100);
    }
}
void TetrisCard::RemoveToch()
{
    _eventDispatcher->removeEventListener(touchListener);
    touchListener=nullptr;
}


bool TetrisCard::onTouchBegan(cocos2d::Touch* touch, cocos2d::Event* event)
{
    if (m_Rect.containsPoint(touch->getLocation())) {
        touchListener->setSwallowTouches(true);
    }else
    {
        touchListener->setSwallowTouches(false);
    }
    return true;
}

void TetrisCard::onTouchEnded(cocos2d::Touch* touch, cocos2d::Event* event)
{
    if (m_Rect.containsPoint(touch->getLocation())) {
        //CCLOG("Touch Sprite Ended %s",m_DispStr.c_str());
    }
}


Tetris_Block::~Tetris_Block()
{
    
}

Tetris_Block* Tetris_Block::createBlock(BlockType bt,BlockOrien bo,int whsize,Vec2 pos)
{
    Tetris_Block *block = new Tetris_Block();
    if (block && block->init())
    {
        block->autorelease();
        block->blockInit(bt, bo, whsize,pos);
        return block;
    }
    CC_SAFE_DELETE(block);
    
    return NULL;
}

bool Tetris_Block::init()
{
    if (!Layer::init())
    {
        return false;
    }
    return true;
}

void Tetris_Block::blockInit(BlockType bt,BlockOrien bo,int whsize,Vec2 pos)
{
    m_BlockType = bt;
    m_BlockOrien = bo;
    m_WHSize = whsize;
    m_Pos = pos;
    switch (bt) {
        default:
        case btLetterI:
        {
            this->CreateBlockI();
        }
            break;
        case btLetterJ:
        {
            this->CreateBlockJ();
        }
            break;
        case btLetterL:
        {
            this->CreateBlockL();
        }
            break;
        case btLetterO:
        {
            this->CreateBlockO();
        }
            break;
        case btLetterS:
        {
            this->CreateBlockS();
        }
            break;
        case btLetterT:
        {
            this->CreateBlockT();
        }
            break;
        case btLetterZ:
        {
            this->CreateBlockZ();
        }
            break;
    }
    this->CalcBlockRect();
}

void Tetris_Block::CreateBlockI()
{
    TetrisCard* card1=TetrisCard::createTetrisCard(1, m_WHSize, m_WHSize, m_Pos.x-m_WHSize, m_Pos.y);
    cardArr[0]=card1;
    this->addChild(card1);

    TetrisCard* card2=TetrisCard::createTetrisCard(1, m_WHSize, m_WHSize, m_Pos.x, m_Pos.y);
    cardArr[1]=card2;
    this->addChild(card2);

    TetrisCard* card3=TetrisCard::createTetrisCard(1, m_WHSize, m_WHSize, m_Pos.x+m_WHSize, m_Pos.y);
    cardArr[2]=card3;
    this->addChild(card3);

    TetrisCard* card4=TetrisCard::createTetrisCard(1, m_WHSize, m_WHSize, m_Pos.x+m_WHSize*2, m_Pos.y);
    cardArr[3]=card4;
    this->addChild(card4);
}

void Tetris_Block::CreateBlockJ()
{
    TetrisCard* card1=TetrisCard::createTetrisCard(1, m_WHSize, m_WHSize, m_Pos.x-m_WHSize, m_Pos.y);
    cardArr[0]=card1;
    this->addChild(card1);
    
    TetrisCard* card2=TetrisCard::createTetrisCard(1, m_WHSize, m_WHSize, m_Pos.x, m_Pos.y);
    cardArr[1]=card2;
    this->addChild(card2);
    
    TetrisCard* card3=TetrisCard::createTetrisCard(1, m_WHSize, m_WHSize, m_Pos.x+m_WHSize, m_Pos.y);
    cardArr[2]=card3;
    this->addChild(card3);
    
    TetrisCard* card4=TetrisCard::createTetrisCard(1, m_WHSize, m_WHSize, m_Pos.x+m_WHSize, m_Pos.y-m_WHSize);
    cardArr[3]=card4;
    this->addChild(card4);
}

void Tetris_Block::CreateBlockL()
{
    TetrisCard* card1=TetrisCard::createTetrisCard(1, m_WHSize, m_WHSize, m_Pos.x-m_WHSize, m_Pos.y);
    cardArr[0]=card1;
    this->addChild(card1);
    
    TetrisCard* card2=TetrisCard::createTetrisCard(1, m_WHSize, m_WHSize, m_Pos.x, m_Pos.y);
    cardArr[1]=card2;
    this->addChild(card2);
    
    TetrisCard* card3=TetrisCard::createTetrisCard(1, m_WHSize, m_WHSize, m_Pos.x+m_WHSize, m_Pos.y);
    cardArr[2]=card3;
    this->addChild(card3);
    
    TetrisCard* card4=TetrisCard::createTetrisCard(1, m_WHSize, m_WHSize, m_Pos.x+m_WHSize, m_Pos.y+m_WHSize);
    cardArr[3]=card4;
    this->addChild(card4);
}


void Tetris_Block::CreateBlockO()
{
    TetrisCard* card1=TetrisCard::createTetrisCard(1, m_WHSize, m_WHSize, m_Pos.x-m_WHSize, m_Pos.y);
    cardArr[0]=card1;
    this->addChild(card1);
    
    TetrisCard* card2=TetrisCard::createTetrisCard(1, m_WHSize, m_WHSize, m_Pos.x, m_Pos.y);
    cardArr[1]=card2;
    this->addChild(card2);
    
    TetrisCard* card3=TetrisCard::createTetrisCard(1, m_WHSize, m_WHSize, m_Pos.x, m_Pos.y+m_WHSize);
    cardArr[2]=card3;
    this->addChild(card3);
    
    TetrisCard* card4=TetrisCard::createTetrisCard(1, m_WHSize, m_WHSize, m_Pos.x-m_WHSize, m_Pos.y+m_WHSize);
    cardArr[3]=card4;
    this->addChild(card4);
}

void Tetris_Block::CreateBlockS()
{
    TetrisCard* card1=TetrisCard::createTetrisCard(1, m_WHSize, m_WHSize, m_Pos.x-m_WHSize, m_Pos.y);
    cardArr[0]=card1;
    this->addChild(card1);
    
    TetrisCard* card2=TetrisCard::createTetrisCard(1, m_WHSize, m_WHSize, m_Pos.x, m_Pos.y);
    cardArr[1]=card2;
    this->addChild(card2);
    
    TetrisCard* card3=TetrisCard::createTetrisCard(1, m_WHSize, m_WHSize, m_Pos.x, m_Pos.y+m_WHSize);
    cardArr[2]=card3;
    this->addChild(card3);
    
    TetrisCard* card4=TetrisCard::createTetrisCard(1, m_WHSize, m_WHSize, m_Pos.x+m_WHSize, m_Pos.y+m_WHSize);
    cardArr[3]=card4;
    this->addChild(card4);
}

void Tetris_Block::CreateBlockT()
{
    TetrisCard* card1=TetrisCard::createTetrisCard(1, m_WHSize, m_WHSize, m_Pos.x-m_WHSize, m_Pos.y);
    cardArr[0]=card1;
    this->addChild(card1);
    
    TetrisCard* card2=TetrisCard::createTetrisCard(1, m_WHSize, m_WHSize, m_Pos.x, m_Pos.y);
    cardArr[1]=card2;
    this->addChild(card2);
    
    TetrisCard* card3=TetrisCard::createTetrisCard(1, m_WHSize, m_WHSize, m_Pos.x+m_WHSize, m_Pos.y);
    cardArr[2]=card3;
    this->addChild(card3);
    
    TetrisCard* card4=TetrisCard::createTetrisCard(1, m_WHSize, m_WHSize, m_Pos.x, m_Pos.y+m_WHSize);
    cardArr[3]=card4;
    this->addChild(card4);
}

void Tetris_Block::CreateBlockZ()
{
    TetrisCard* card1=TetrisCard::createTetrisCard(1, m_WHSize, m_WHSize, m_Pos.x-m_WHSize, m_Pos.y);
    cardArr[0]=card1;
    this->addChild(card1);
    
    TetrisCard* card2=TetrisCard::createTetrisCard(1, m_WHSize, m_WHSize, m_Pos.x, m_Pos.y);
    cardArr[1]=card2;
    this->addChild(card2);
    
    TetrisCard* card3=TetrisCard::createTetrisCard(1, m_WHSize, m_WHSize, m_Pos.x, m_Pos.y-m_WHSize);
    cardArr[2]=card3;
    this->addChild(card3);
    
    TetrisCard* card4=TetrisCard::createTetrisCard(1, m_WHSize, m_WHSize, m_Pos.x+m_WHSize, m_Pos.y-m_WHSize);
    cardArr[3]=card4;
    this->addChild(card4);
}

void Tetris_Block::setBlockOrien(BlockOrien bo)
{
    m_BlockOrien = bo;
}

void Tetris_Block::TurnOrien()
{
    m_BlockOrien = (BlockOrien)(((int)m_BlockOrien+1)%boMax);
}

void Tetris_Block::MoveDown()
{
    if(m_BlockRect.getMinY()>(m_BackgroundRect.getMinY()+m_WHSize/2))
    {
        m_Pos.y = m_Pos.y-m_WHSize;
        for (int i=0; i<BlockSize; i++) {
            Vec2 p=cardArr[i]->getPixelPos();
            p.y=p.y-m_WHSize;
            cardArr[i]->setPixelPos(p);
        }
        this->CalcBlockRect();
    }
    else
    {
        //TODO:reach to down
    }
}

void Tetris_Block::MoveLeft()
{
    if(m_BlockRect.getMinX()>(m_BackgroundRect.getMinX()+m_WHSize/2))
    {
        m_Pos.x = m_Pos.x-m_WHSize;
        for (int i=0; i<BlockSize; i++) {
            Vec2 p=cardArr[i]->getPixelPos();
            p.x=p.x-m_WHSize;
            cardArr[i]->setPixelPos(p);
        }
        this->CalcBlockRect();
    }
    else
    {
        //TODO:reach to down
    }
}
void Tetris_Block::MoveRight()
{
    if(m_BlockRect.getMaxX()<(m_BackgroundRect.getMaxX()-m_WHSize/2))
    {
        m_Pos.x = m_Pos.x+m_WHSize;
        for (int i=0; i<BlockSize; i++) {
            Vec2 p=cardArr[i]->getPixelPos();
            p.x=p.x+m_WHSize;
            cardArr[i]->setPixelPos(p);
        }
        this->CalcBlockRect();
    }
    else
    {
        //TODO:reach to down
    }
}

Rect Tetris_Block::getBlockRect()
{
    return m_BlockRect;
}

void Tetris_Block::setBlockRect(Rect rect)
{
    m_BlockRect = rect;
}

void Tetris_Block::setBackgroundRect(Rect rect)
{
    m_BackgroundRect = rect;
}

Rect Tetris_Block::getBackgroundRect()
{
    return m_BackgroundRect;
}

void Tetris_Block::CalcBlockRect()
{
    //minpos
    Vec2 min_vec=Vec2(m_WHSize*5,m_WHSize*5);
    for (int i=0; i<BlockSize; i++) {
        if(min_vec.x>cardArr[i]->getPixelPos().x)
            min_vec.x=cardArr[i]->getPixelPos().x;
        if(min_vec.y>cardArr[i]->getPixelPos().y)
            min_vec.y=cardArr[i]->getPixelPos().y;
    }
    Vec2 max_vec=Vec2(0,0);
    for (int i=0; i<BlockSize; i++) {
        if(max_vec.x<cardArr[i]->getPixelPos().x)
            max_vec.x=cardArr[i]->getPixelPos().x;
        if(max_vec.y<cardArr[i]->getPixelPos().y)
            max_vec.y=cardArr[i]->getPixelPos().y;
    }
    m_BlockRect = Rect(min_vec.x, min_vec.y, max_vec.x-min_vec.x+m_WHSize, max_vec.y-min_vec.y+m_WHSize);
}



