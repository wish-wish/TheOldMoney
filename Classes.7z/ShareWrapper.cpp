//
//  ShareSDKWrapper.cpp
//  HelloCpp
//
//  Created by cc lin on 15/5/27.
//
//

#include "ShareWrapper.h"

ShareWrapper* sdkinst=nullptr;

void authResultHandler(C2DXResponseState state, C2DXPlatType platType, __Dictionary *error)
{
    CCLOG("authResultHandler state=%d",state);
    switch (state) {
        case C2DXResponseStateSuccess:
            C2DXShareSDK::toast("授权成功");
            break;
        case C2DXResponseStateFail:
            C2DXShareSDK::toast("授权失败");
            break;
        default:
            C2DXShareSDK::toast("授权取消");
            break;
    }
}

void getUserResultHandler(C2DXResponseState state, C2DXPlatType platType, __Dictionary *userInfo, __Dictionary *error, __Dictionary *db)
{
    CCLOG("getUserResultHandler state=%s",state);
    if (state == C2DXResponseStateSuccess)
    {
        //输出用户信息
        Array *allKeys = db -> allKeys();
        allKeys->retain();
        for (int i = 0; i < allKeys -> count(); i++)
        {
            String *key = (String *)allKeys -> objectAtIndex(i);
            Object *obj = db -> objectForKey(key -> getCString());
            
            CCLog("key = %s", key -> getCString());
            if (dynamic_cast<String *>(obj))
            {
                CCLog("value = %s", dynamic_cast<String *>(obj) -> getCString());
            }
            else if (dynamic_cast<Integer *>(obj))
            {
                CCLog("value = %d", dynamic_cast<Integer *>(obj) -> getValue());
            }
            else if (dynamic_cast<Double *>(obj))
            {
                CCLog("value = %f", dynamic_cast<Double *>(obj) -> getValue());
            }
        }
        allKeys->release();
    }
}

void shareResultHandler(C2DXResponseState state, C2DXPlatType platType, __Dictionary *shareInfo, __Dictionary *error)
{
    CCLog("shareResultHandler state=%d",state);
    switch (state) {
        case C2DXResponseStateSuccess:
            C2DXShareSDK::toast("分享成功");
            break;
        case C2DXResponseStateFail:
            C2DXShareSDK::toast("分享失败");
            break;
        default:
            C2DXShareSDK::toast("分享取消");
            break;
    }
}

void followResultHandler(C2DXResponseState state, C2DXPlatType platType,  __Dictionary *error)
{
    CCLOG("shareResultHandler state=%d",state);
    switch (state) {
        case C2DXResponseStateSuccess:
            C2DXShareSDK::toast("关注成功");
            break;
        case C2DXResponseStateFail:
            C2DXShareSDK::toast("关注失败");
            break;
        default:
            C2DXShareSDK::toast("关注取消");
            break;
    }
}

ShareWrapper* ShareWrapper::getInstance()
{
    if(sdkinst==nullptr)
        sdkinst=new ShareWrapper();
    return sdkinst;
}

void ShareWrapper::authMenu(map<string,string> params)
{
    C2DXShareSDK::authorize(C2DXPlatTypeFacebook, authResultHandler);
}

void ShareWrapper::cancelAuth(map<string,string> params)
{
    C2DXShareSDK::cancelAuthorize(C2DXPlatTypeFacebook);
}

void ShareWrapper::hasAuth(map<string,string> params)
{
    if (C2DXShareSDK::hasAutorized(C2DXPlatTypeFacebook))
    {
        C2DXShareSDK::toast("用户已授权");
    }
    else
    {
        C2DXShareSDK::toast("用户尚未授权");
    }
}

void ShareWrapper::getAuthInfo(map<string,string> params)
{
    //此方法可以获取用户授权后的用户信息，若未授权返回为空
    __Dictionary* userInfo = C2DXShareSDK::getAuthInformation(C2DXPlatTypeQQ);
}

void ShareWrapper::getUserInfo(map<string,string> params)
{
    C2DXShareSDK::getUserInfo(C2DXPlatTypeQQ, getUserResultHandler);
}

void ShareWrapper::getFriendList(map<string,string> params)
{
    //account 填入昵称
    C2DXShareSDK::getFriendList(C2DXPlatTypeSinaWeibo, 10, 1, "沂谋大爱蓝军", getUserResultHandler);
}

void ShareWrapper::followFriend(map<string,string> params)
{
    //account 填入昵称
    C2DXShareSDK::followFriend(C2DXPlatTypeSinaWeibo, "淡淡想起丶", followResultHandler);
}

void ShareWrapper::shareForWechatTimeLine(map<string,string> params)
{
    __Dictionary *content = __Dictionary::create();
    //Dictionary可用的Key如下，如果需要用到其它字段，可自行参考Sample中的代码实现：
    // (并不是所有平台都有这些字段，需要参考文档http://wiki.mob.com/Android_%E4%B8%8D%E5%90%8C%E5%B9%B3%E5%8F%B0%E5%88%86%E4%BA%AB%E5%86%85%E5%AE%B9%E7%9A%84%E8%AF%A6%E7%BB%86%E8%AF%B4%E6%98%8E
    content -> setObject(String::create("jajax"), "content"); //要分享的内容，注意在文档中content对应的是text字段
    //content -> setObject(String::create("http://img0.bdstatic.com/img/image/shouye/systsy-11927417755.jpg"), "image"); //可以是本地路径（如：/sdcard/a.jpg）或是一个URL
    //content -> setObject(String::create("for title"), "title");
    //content -> setObject(String::create("http://sharesdk.cn"), "url");
    //content -> setObject(String::createWithFormat("%d", C2DXContentTypeImage), "type");
    C2DXShareSDK::shareContent(C2DXPlatTypeSinaWeibo , content , false, shareResultHandler);
}

void ShareWrapper::shareMenu(map<string,string> params)
{
    __Dictionary *content = __Dictionary::create();
    //Dictionary可用的Key如下，如果需要用到其它字段，可自行参考Sample中的代码实现：
    // (并不是所有平台都有这些字段，需要参考文档http://wiki.mob.com/Android_%E4%B8%8D%E5%90%8C%E5%B9%B3%E5%8F%B0%E5%88%86%E4%BA%AB%E5%86%85%E5%AE%B9%E7%9A%84%E8%AF%A6%E7%BB%86%E8%AF%B4%E6%98%8E)
    
    content -> setObject(String::create("jaja"), "content"); //要分享的内容，注意在文档中content对应的是text字段
    content -> setObject(String::create("http://img0.bdstatic.com/img/image/shouye/systsy-11927417755.jpg"), "image"); //可以是本地路径（如：/sdcard/a.jpg）或是一个URL
    content -> setObject(String::create("for title"), "title");
    content -> setObject(String::create("测试描述"), "description");
    content -> setObject(String::create("http://sharesdk.cn"), "url");
    content -> setObject(String::createWithFormat("%d", C2DXContentTypeNews), "type");
    content -> setObject(String::create("http://sharesdk.cn"), "siteUrl");
    content -> setObject(String::create("ShareSDK"), "site");
    content -> setObject(String::create("http://mp3.mwap8.com/destdir/Music/2009/20090601/ZuiXuanMinZuFeng20090601119.mp3"), "musicUrl");
    content -> setObject(String::create("extInfo"), "extInfo"); //微信分享应用时传给应用的附加信息
    C2DXShareSDK::showShareMenu(NULL, content, cocos2d::Point(100, 100), C2DXMenuArrowDirectionLeft, shareResultHandler);
    //    C2DXShareSDK::showShareView(C2DXPlatTypeSinaWeibo, content, shareResultHandler);
}

void ShareWrapper::initPlatformConfig()
{
    //新浪微博
    __Dictionary *sinaConfigDict = __Dictionary::create();
    sinaConfigDict -> setObject(String::create("568898243"), "app_key");
    sinaConfigDict -> setObject(String::create("38a4f8204cc784f81f9f0daaf31e02e3"), "app_secret");
    sinaConfigDict -> setObject(String::create("http://www.sharesdk.cn"), "redirect_uri");
    C2DXShareSDK::setPlatformConfig(C2DXPlatTypeSinaWeibo, sinaConfigDict);
    
    //腾讯微博
    __Dictionary *tcConfigDict = __Dictionary::create();
    tcConfigDict -> setObject(String::create("801307650"), "app_key");
    tcConfigDict -> setObject(String::create("ae36f4ee3946e1cbb98d6965b0b2ff5c"), "app_secret");
    tcConfigDict -> setObject(String::create("http://www.sharesdk.cn"), "redirect_uri");
    C2DXShareSDK::setPlatformConfig(C2DXPlatTypeTencentWeibo, tcConfigDict);
    
    //短信
    C2DXShareSDK::setPlatformConfig(C2DXPlatTypeSMS, NULL);
    
    //QQ空间
    __Dictionary *qzConfigDict = __Dictionary::create();
    qzConfigDict -> setObject(String::create("100371282"), "app_id");
    qzConfigDict -> setObject(String::create("aed9b0303e3ed1e27bae87c33761161d"), "app_key");
    C2DXShareSDK::setPlatformConfig(C2DXPlatTypeQZone, qzConfigDict);
    
    //微信
    __Dictionary *wcConfigDict = __Dictionary::create();
    wcConfigDict -> setObject(String::create("wx4868b35061f87885"), "app_id");
    C2DXShareSDK::setPlatformConfig(C2DXPlatTypeWeixiSession, wcConfigDict);
    C2DXShareSDK::setPlatformConfig(C2DXPlatTypeWeixiTimeline, wcConfigDict);
    C2DXShareSDK::setPlatformConfig(C2DXPlatTypeWeixiFav, wcConfigDict);
    
    //QQ
    __Dictionary *qqConfigDict = __Dictionary::create();
    qqConfigDict -> setObject(String::create("100371282"), "app_id");
    C2DXShareSDK::setPlatformConfig(C2DXPlatTypeQQ, qqConfigDict);
    
    //Facebook
    __Dictionary *fbConfigDict = __Dictionary::create();
    fbConfigDict -> setObject(String::create("107704292745179"), "api_key");
    fbConfigDict -> setObject(String::create("38053202e1a5fe26c80c753071f0b573"), "app_secret");
    C2DXShareSDK::setPlatformConfig(C2DXPlatTypeFacebook, fbConfigDict);
    
    //Twitter
    __Dictionary *twConfigDict = __Dictionary::create();
    twConfigDict -> setObject(String::create("mnTGqtXk0TYMXYTN7qUxg"), "consumer_key");
    twConfigDict -> setObject(String::create("ROkFqr8c3m1HXqS3rm3TJ0WkAJuwBOSaWhPbZ9Ojuc"), "consumer_secret");
    twConfigDict -> setObject(String::create("http://www.sharesdk.cn"), "redirect_uri");
    C2DXShareSDK::setPlatformConfig(C2DXPlatTypeTwitter, twConfigDict);
    
    //Google+
    __Dictionary *gpConfigDict = __Dictionary::create();
    gpConfigDict -> setObject(String::create("232554794995.apps.googleusercontent.com"), "client_id");
    gpConfigDict -> setObject(String::create("PEdFgtrMw97aCvf0joQj7EMk"), "client_secret");
    gpConfigDict -> setObject(String::create("http://localhost"), "redirect_uri");
    C2DXShareSDK::setPlatformConfig(C2DXPlatTypeGooglePlus, gpConfigDict);
    
    //人人网
    __Dictionary *rrConfigDict = __Dictionary::create();
    rrConfigDict -> setObject(String::create("226427"), "app_id");
    rrConfigDict -> setObject(String::create("fc5b8aed373c4c27a05b712acba0f8c3"), "app_key");
    rrConfigDict -> setObject(String::create("f29df781abdd4f49beca5a2194676ca4"), "secret_key");
    C2DXShareSDK::setPlatformConfig(C2DXPlatTypeRenren, rrConfigDict);
    
    //开心网
    __Dictionary *kxConfigDict = __Dictionary::create();
    kxConfigDict -> setObject(String::create("358443394194887cee81ff5890870c7c"), "api_key");
    kxConfigDict -> setObject(String::create("da32179d859c016169f66d90b6db2a23"), "secret_key");
    kxConfigDict -> setObject(String::create("http://www.sharesdk.cn/"), "redirect_uri");
    C2DXShareSDK::setPlatformConfig(C2DXPlatTypeKaixin, kxConfigDict);
    
    //邮件
    C2DXShareSDK::setPlatformConfig(C2DXPlatTypeMail, NULL);
    
    //打印
    C2DXShareSDK::setPlatformConfig(C2DXPlatTypeAirPrint, NULL);
    
    //拷贝
    C2DXShareSDK::setPlatformConfig(C2DXPlatTypeCopy, NULL);
    
    //搜狐微博
    __Dictionary *shwbConfigDict = __Dictionary::create();
    shwbConfigDict -> setObject(String::create("SAfmTG1blxZY3HztESWx"), "consumer_key");
    shwbConfigDict -> setObject(String::create("yfTZf)!rVwh*3dqQuVJVsUL37!F)!yS9S!Orcsij"), "consumer_secret");
    shwbConfigDict -> setObject(String::create("http://www.sharesdk.cn"), "callback_uri");
    C2DXShareSDK::setPlatformConfig(C2DXPlatTypeSohuWeibo, shwbConfigDict);
    
    //网易微博
    __Dictionary *neConfigDict = __Dictionary::create();
    neConfigDict -> setObject(String::create("T5EI7BXe13vfyDuy"), "consumer_key");
    neConfigDict -> setObject(String::create("gZxwyNOvjFYpxwwlnuizHRRtBRZ2lV1j"), "consumer_secret");
    neConfigDict -> setObject(String::create("http://www.shareSDK.cn"), "redirect_uri");
    C2DXShareSDK::setPlatformConfig(C2DXPlatType163Weibo, neConfigDict);
    
    //豆瓣
    __Dictionary *dbConfigDict = __Dictionary::create();
    dbConfigDict -> setObject(String::create("02e2cbe5ca06de5908a863b15e149b0b"), "api_key");
    dbConfigDict -> setObject(String::create("9f1e7b4f71304f2f"), "secret");
    dbConfigDict -> setObject(String::create("http://www.sharesdk.cn"), "redirect_uri");
    C2DXShareSDK::setPlatformConfig(C2DXPlatTypeDouBan, dbConfigDict);
    
    //印象笔记
    __Dictionary *enConfigDict = __Dictionary::create();
    enConfigDict -> setObject(String::create("sharesdk-7807"), "consumer_key");
    enConfigDict -> setObject(String::create("d05bf86993836004"), "consumer_secret");
    enConfigDict -> setObject(String::create("0"), "host_type");
    C2DXShareSDK::setPlatformConfig(C2DXPlatTypeEvernote, enConfigDict);
    
    //LinkedIn
    __Dictionary *liConfigDict = __Dictionary::create();
    liConfigDict -> setObject(String::create("ejo5ibkye3vo"), "api_key");
    liConfigDict -> setObject(String::create("cC7B2jpxITqPLZ5M"), "secret_key");
    liConfigDict -> setObject(String::create("http://sharesdk.cn"), "redirect_url");
    C2DXShareSDK::setPlatformConfig(C2DXPlatTypeLinkedIn, liConfigDict);
    
    //Pinterest
    __Dictionary *piConfigDict = __Dictionary::create();
    piConfigDict -> setObject(String::create("1432928"), "client_id");
    C2DXShareSDK::setPlatformConfig(C2DXPlatTypePinterest, piConfigDict);
    
    //Pocket
    __Dictionary *poConfigDict = __Dictionary::create();
    poConfigDict -> setObject(String::create("11496-de7c8c5eb25b2c9fcdc2b627"), "consumer_key");
    poConfigDict -> setObject(String::create("pocketapp1234"), "redirect_uri");
    C2DXShareSDK::setPlatformConfig(C2DXPlatTypePocket, poConfigDict);
    
    //Instapaper
    __Dictionary *ipConfigDict = __Dictionary::create();
    ipConfigDict -> setObject(String::create("4rDJORmcOcSAZL1YpqGHRI605xUvrLbOhkJ07yO0wWrYrc61FA"), "consumer_key");
    ipConfigDict -> setObject(String::create("GNr1GespOQbrm8nvd7rlUsyRQsIo3boIbMguAl9gfpdL0aKZWe"), "consumer_secret");
    C2DXShareSDK::setPlatformConfig(C2DXPlatTypeInstapaper, ipConfigDict);
    
    //有道云笔记
    __Dictionary *ydConfigDict = __Dictionary::create();
    ydConfigDict -> setObject(String::create("dcde25dca105bcc36884ed4534dab940"), "consumer_key");
    ydConfigDict -> setObject(String::create("d98217b4020e7f1874263795f44838fe"), "consumer_secret");
    ydConfigDict -> setObject(String::create("http://www.sharesdk.cn/"), "oauth_callback");
    ydConfigDict -> setObject(String::create("1"), "host_type");
    C2DXShareSDK::setPlatformConfig(C2DXPlatTypeYouDaoNote, ydConfigDict);
    
    //搜狐随身看
    __Dictionary *shkConfigDict = __Dictionary::create();
    shkConfigDict -> setObject(String::create("e16680a815134504b746c86e08a19db0"), "app_key");
    shkConfigDict -> setObject(String::create("b8eec53707c3976efc91614dd16ef81c"), "app_secret");
    shkConfigDict -> setObject(String::create("http://sharesdk.cn"), "redirect_uri");
    C2DXShareSDK::setPlatformConfig(C2DXPlatTypeSohuKan, shkConfigDict);
    
    //Flickr
    __Dictionary *flickrConfigDict = __Dictionary::create();
    flickrConfigDict -> setObject(String::create("33d833ee6b6fca49943363282dd313dd"), "api_key");
    flickrConfigDict -> setObject(String::create("3a2c5b42a8fbb8bb"), "api_secret");
    C2DXShareSDK::setPlatformConfig(C2DXPlatTypeFlickr, flickrConfigDict);
    
    //Tumblr
    __Dictionary *tumblrConfigDict = __Dictionary::create();
    tumblrConfigDict -> setObject(String::create("2QUXqO9fcgGdtGG1FcvML6ZunIQzAEL8xY6hIaxdJnDti2DYwM"), "consumer_key");
    tumblrConfigDict -> setObject(String::create("3Rt0sPFj7u2g39mEVB3IBpOzKnM3JnTtxX2bao2JKk4VV1gtNo"), "consumer_secret");
    tumblrConfigDict -> setObject(String::create("http://sharesdk.cn"), "callback_url");
    C2DXShareSDK::setPlatformConfig(C2DXPlatTypeTumblr, tumblrConfigDict);
    
    //Dropbox
    __Dictionary *dropboxConfigDict = __Dictionary::create();
    dropboxConfigDict -> setObject(String::create("7janx53ilz11gbs"), "app_key");
    dropboxConfigDict -> setObject(String::create("c1hpx5fz6tzkm32"), "app_secret");
    C2DXShareSDK::setPlatformConfig(C2DXPlatTypeDropbox, dropboxConfigDict);
    
    //Instagram
    __Dictionary *instagramConfigDict = __Dictionary::create();
    instagramConfigDict -> setObject(String::create("ff68e3216b4f4f989121aa1c2962d058"), "client_id");
    instagramConfigDict -> setObject(String::create("1b2e82f110264869b3505c3fe34e31a1"), "client_secret");
    instagramConfigDict -> setObject(String::create("http://sharesdk.cn"), "redirect_uri");
    C2DXShareSDK::setPlatformConfig(C2DXPlatTypeInstagram, instagramConfigDict);
    
    //VK
    __Dictionary *vkConfigDict = __Dictionary::create();
    vkConfigDict -> setObject(String::create("3921561"), "application_id");
    vkConfigDict -> setObject(String::create("6Qf883ukLDyz4OBepYF1"), "secret_key");
    C2DXShareSDK::setPlatformConfig(C2DXPlatTypeVKontakte, vkConfigDict);
}
