//
//  ShareSDKWrapper.h
//  HelloCpp
//
//  Created by cc lin on 15/5/27.
//
//

#ifndef __HelloCpp__ShareSDKWrapper__
#define __HelloCpp__ShareSDKWrapper__

#include <stdio.h>
#include "C2DXShareSDK.h"
#include "cocos2d.h"
#include "string"
#include "map"

USING_NS_CC;
using namespace cn::sharesdk;
using namespace std;

class ShareWrapper
{
public:
    static ShareWrapper* getInstance();
    
    void initPlatformConfig();
    void authMenu(map<string,string> params);
    void cancelAuth(map<string,string> params);
    void hasAuth(map<string,string> params);
    void getAuthInfo(map<string,string> params);
    void getUserInfo(map<string,string> params);
    void getFriendList(map<string,string> params);
    void followFriend(map<string,string> params);
    void shareForWechatTimeLine(map<string,string> params);
    void shareMenu(map<string,string> params);
};

#endif /* defined(__HelloCpp__ShareSDKWrapper__) */
