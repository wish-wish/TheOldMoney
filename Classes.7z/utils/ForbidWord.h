﻿#pragma once

#include "cocos2d.h"

USING_NS_CC;
using namespace std;

vector<string> getForbidWord();
bool isInForbidWord(string word);
